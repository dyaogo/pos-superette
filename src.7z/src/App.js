import React, { useState, useEffect } from 'react';
import { MultiStoreProvider, useMultiStore } from './contexts/MultiStoreContext';
import StoreSelector from './components/StoreSelector';
import SalesModule from './modules/sales/SalesModule';
import InventoryModule from './modules/inventory/InventoryModule';
import CashRegisterModule from './modules/cash/CashRegisterModule';
import CreditManagementModule from './modules/credits/CreditManagementModule';
import DashboardModule from './modules/dashboard/DashboardModule';
import ReportsModule from './modules/reports/ReportsModule';
import { MobileNavigation, useResponsive } from './components/ResponsiveComponents';
import { CloudSyncPanel } from './services/CloudSyncService';
import { ShoppingCart, Package, Users, DollarSign, Home, BarChart3, Settings, Sun, Moon, Database, AlertTriangle, Calculator, CreditCard, ArrowLeftRight } from 'lucide-react';

// Composant principal avec le Provider
function App() {
  return (
    <MultiStoreProvider>
      <AppContent />
    </MultiStoreProvider>
  );
}

// Contenu de l'application
function AppContent() {
  const { 
    appSettings, 
    setAppSettings, 
    getStats, 
    clearAllData,
    viewMode,
    getCurrentStore,
    transferStock,
    stores,
    globalProducts
  } = useMultiStore();
  
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [activeModule, setActiveModule] = useState('dashboard');
  const [showTransferModal, setShowTransferModal] = useState(false);
  const { isMobile } = useResponsive();
  
  const stats = getStats();

  // Effet pour le mode sombre
  useEffect(() => {
    if (appSettings.darkMode) {
      document.body.style.background = '#1a202c';
    } else {
      document.body.style.background = '#f7fafc';
    }
  }, [appSettings.darkMode]);

  // Styles dynamiques basés sur le thème
  const isDark = appSettings.darkMode;
  const styles = {
    container: {
      minHeight: '100vh',
      background: isDark ? 'linear-gradient(135deg, #1e3a8a 0%, #581c87 100%)' : 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '20px'
    },
    loginBox: {
      background: isDark ? '#2d3748' : 'white',
      borderRadius: '12px',
      padding: '40px',
      boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.3)',
      maxWidth: '400px',
      width: '100%'
    },
    title: {
      fontSize: '28px',
      fontWeight: 'bold',
      color: isDark ? '#f7fafc' : '#1a202c',
      marginBottom: '10px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: '10px'
    },
    subtitle: {
      color: isDark ? '#cbd5e0' : '#718096',
      marginBottom: '30px',
      textAlign: 'center'
    },
    button: {
      width: '100%',
      padding: '12px 24px',
      background: '#4299e1',
      color: 'white',
      border: 'none',
      borderRadius: '8px',
      fontSize: '16px',
      fontWeight: '600',
      cursor: 'pointer',
      transition: 'background 0.2s'
    },
    dashboard: {
      minHeight: '100vh',
      background: isDark ? '#1a202c' : '#f7fafc',
      display: 'flex',
      flexDirection: 'column'
    },
    header: {
      background: isDark ? '#2d3748' : 'white',
      padding: '15px 40px',
      boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    },
    nav: {
      background: isDark ? '#2d3748' : 'white',
      padding: '0 40px',
      borderBottom: `1px solid ${isDark ? '#4a5568' : '#e2e8f0'}`,
      display: 'flex',
      gap: '20px',
      alignItems: 'center'
    },
    navButton: {
      padding: '15px 20px',
      background: 'transparent',
      border: 'none',
      borderBottom: '3px solid transparent',
      cursor: 'pointer',
      fontSize: '14px',
      fontWeight: '600',
      color: isDark ? '#cbd5e0' : '#4a5568',
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      transition: 'all 0.2s'
    },
    navButtonActive: {
      borderBottomColor: '#4299e1',
      color: '#4299e1'
    },
    main: {
      flex: 1,
      paddingBottom: isMobile ? '80px' : '0'
    }
  };

  // Module Clients
  const CustomersModule = () => {
    const { customers, setCustomers } = useMultiStore();
    const [showAddModal, setShowAddModal] = useState(false);
    const [newCustomer, setNewCustomer] = useState({ name: '', phone: '', email: '' });

    const addCustomer = () => {
      if (newCustomer.name) {
        setCustomers([...customers, {
          id: Date.now(),
          ...newCustomer,
          totalPurchases: 0,
          points: 0,
          createdAt: new Date().toISOString()
        }]);
        setNewCustomer({ name: '', phone: '', email: '' });
        setShowAddModal(false);
      }
    };

    return (
      <div style={{ padding: '20px', background: isDark ? '#2d3748' : 'white', borderRadius: '8px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
          <h2 style={{ fontSize: '24px', color: isDark ? '#f7fafc' : '#2d3748' }}>Gestion Clients</h2>
          <button
            onClick={() => setShowAddModal(true)}
            style={{
              padding: '10px 20px',
              background: '#3b82f6',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              cursor: 'pointer'
            }}
          >
            + Nouveau Client
          </button>
        </div>

        {/* Table des clients */}
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ borderBottom: `2px solid ${isDark ? '#4a5568' : '#e2e8f0'}` }}>
                <th style={{ padding: '10px', textAlign: 'left', color: isDark ? '#a0aec0' : '#718096' }}>Nom</th>
                <th style={{ padding: '10px', textAlign: 'left', color: isDark ? '#a0aec0' : '#718096' }}>Téléphone</th>
                <th style={{ padding: '10px', textAlign: 'left', color: isDark ? '#a0aec0' : '#718096' }}>Email</th>
                <th style={{ padding: '10px', textAlign: 'left', color: isDark ? '#a0aec0' : '#718096' }}>Total Achats</th>
                <th style={{ padding: '10px', textAlign: 'left', color: isDark ? '#a0aec0' : '#718096' }}>Points</th>
              </tr>
            </thead>
            <tbody>
              {customers.filter(c => c.id !== 1).map(customer => (
                <tr key={customer.id} style={{ borderBottom: `1px solid ${isDark ? '#4a5568' : '#f1f5f9'}` }}>
                  <td style={{ padding: '10px', color: isDark ? '#f7fafc' : '#2d3748' }}>{customer.name}</td>
                  <td style={{ padding: '10px', color: isDark ? '#f7fafc' : '#2d3748' }}>{customer.phone}</td>
                  <td style={{ padding: '10px', color: isDark ? '#f7fafc' : '#2d3748' }}>{customer.email}</td>
                  <td style={{ padding: '10px', color: isDark ? '#f7fafc' : '#2d3748' }}>
                    {customer.totalPurchases.toLocaleString()} {appSettings.currency}
                  </td>
                  <td style={{ padding: '10px' }}>
                    <span style={{
                      padding: '4px 8px',
                      background: '#fef3c7',
                      color: '#92400e',
                      borderRadius: '4px',
                      fontSize: '12px',
                      fontWeight: '600'
                    }}>
                      {customer.points} pts
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Modal d'ajout */}
        {showAddModal && (
          <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: 'rgba(0,0,0,0.5)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 1000
          }}>
            <div style={{
              background: isDark ? '#2d3748' : 'white',
              padding: '30px',
              borderRadius: '12px',
              width: '90%',
              maxWidth: '400px'
            }}>
              <h3 style={{ marginBottom: '20px', color: isDark ? '#f7fafc' : '#2d3748' }}>
                Nouveau Client
              </h3>
              <input
                type="text"
                placeholder="Nom complet"
                value={newCustomer.name}
                onChange={(e) => setNewCustomer({...newCustomer, name: e.target.value})}
                style={{
                  width: '100%',
                  padding: '10px',
                  marginBottom: '10px',
                  border: `1px solid ${isDark ? '#4a5568' : '#e2e8f0'}`,
                  borderRadius: '6px',
                  background: isDark ? '#374151' : 'white',
                  color: isDark ? '#f7fafc' : '#2d3748'
                }}
              />
              <input
                type="tel"
                placeholder="Téléphone"
                value={newCustomer.phone}
                onChange={(e) => setNewCustomer({...newCustomer, phone: e.target.value})}
                style={{
                  width: '100%',
                  padding: '10px',
                  marginBottom: '10px',
                  border: `1px solid ${isDark ? '#4a5568' : '#e2e8f0'}`,
                  borderRadius: '6px',
                  background: isDark ? '#374151' : 'white',
                  color: isDark ? '#f7fafc' : '#2d3748'
                }}
              />
              <input
                type="email"
                placeholder="Email (optionnel)"
                value={newCustomer.email}
                onChange={(e) => setNewCustomer({...newCustomer, email: e.target.value})}
                style={{
                  width: '100%',
                  padding: '10px',
                  marginBottom: '20px',
                  border: `1px solid ${isDark ? '#4a5568' : '#e2e8f0'}`,
                  borderRadius: '6px',
                  background: isDark ? '#374151' : 'white',
                  color: isDark ? '#f7fafc' : '#2d3748'
                }}
              />
              <div style={{ display: 'flex', gap: '10px' }}>
                <button
                  onClick={addCustomer}
                  style={{
                    flex: 1,
                    padding: '10px',
                    background: '#3b82f6',
                    color: 'white',
                    border: 'none',
                    borderRadius: '6px',
                    cursor: 'pointer'
                  }}
                >
                  Ajouter
                </button>
                <button
                  onClick={() => setShowAddModal(false)}
                  style={{
                    flex: 1,
                    padding: '10px',
                    background: '#64748b',
                    color: 'white',
                    border: 'none',
                    borderRadius: '6px',
                    cursor: 'pointer'
                  }}
                >
                  Annuler
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  };

  // Module Settings avec transferts
  const SettingsModule = () => {
    return (
      <div style={{ padding: '20px' }}>
        <div style={{ background: isDark ? '#2d3748' : 'white', padding: '20px', borderRadius: '8px', marginBottom: '20px' }}>
          <h2 style={{ fontSize: '24px', marginBottom: '20px', color: isDark ? '#f7fafc' : '#2d3748' }}>
            Paramètres
          </h2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '15px', maxWidth: '500px' }}>
            <div>
              <label style={{ display: 'block', marginBottom: '5px', color: isDark ? '#a0aec0' : '#718096' }}>
                Nom du magasin
              </label>
              <input
                type="text"
                value={appSettings.storeName}
                onChange={(e) => setAppSettings({...appSettings, storeName: e.target.value})}
                style={{
                  width: '100%',
                  padding: '10px',
                  border: `1px solid ${isDark ? '#4a5568' : '#e2e8f0'}`,
                  borderRadius: '6px',
                  background: isDark ? '#374151' : 'white',
                  color: isDark ? '#f7fafc' : '#2d3748'
                }}
              />
            </div>
            <div>
              <label style={{ display: 'block', marginBottom: '5px', color: isDark ? '#a0aec0' : '#718096' }}>
                Taux de TVA (%)
              </label>
              <input
                type="number"
                value={appSettings.taxRate}
                onChange={(e) => setAppSettings({...appSettings, taxRate: parseInt(e.target.value)})}
                style={{
                  width: '100%',
                  padding: '10px',
                  border: `1px solid ${isDark ? '#4a5568' : '#e2e8f0'}`,
                  borderRadius: '6px',
                  background: isDark ? '#374151' : 'white',
                  color: isDark ? '#f7fafc' : '#2d3748'
                }}
              />
            </div>
          </div>
        </div>

        {/* Section Transferts de Stock */}
        {stores.length > 1 && (
          <div style={{ background: isDark ? '#2d3748' : 'white', padding: '20px', borderRadius: '8px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px' }}>
              <h3 style={{ fontSize: '18px', color: isDark ? '#f7fafc' : '#2d3748' }}>
                Transferts de Stock
              </h3>
              <button
                onClick={() => setShowTransferModal(true)}
                style={{
                  padding: '8px 16px',
                  background: '#10b981',
                  color: 'white',
                  border: 'none',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px'
                }}
              >
                <ArrowLeftRight size={16} />
                Nouveau Transfert
              </button>
            </div>
            <p style={{ color: isDark ? '#a0aec0' : '#64748b', fontSize: '14px' }}>
              Gérez les transferts de stock entre vos magasins pour optimiser les ventes.
            </p>
          </div>
        )}
      </div>
    );
  };

  // Modal de transfert de stock
  const TransferStockModal = () => {
    const [transferData, setTransferData] = useState({
      productId: '',
      quantity: '',
      fromStore: '',
      toStore: '',
      reason: ''
    });

    const handleTransfer = () => {
      try {
        if (!transferData.productId || !transferData.quantity || !transferData.fromStore || !transferData.toStore) {
          alert('Veuillez remplir tous les champs');
          return;
        }

        if (transferData.fromStore === transferData.toStore) {
          alert('Vous ne pouvez pas transférer vers le même magasin');
          return;
        }

        transferStock(
          parseInt(transferData.productId),
          parseInt(transferData.quantity),
          transferData.fromStore,
          transferData.toStore,
          transferData.reason || 'Transfert de stock'
        );

        const fromStoreName = stores.find(s => s.id === transferData.fromStore)?.name;
        const toStoreName = stores.find(s => s.id === transferData.toStore)?.name;
        const productName = globalProducts.find(p => p.id === parseInt(transferData.productId))?.name;

        alert(`Transfert réussi!\n${transferData.quantity} ${productName} transférés de ${fromStoreName} vers ${toStoreName}`);
        setShowTransferModal(false);
        setTransferData({ productId: '', quantity: '', fromStore: '', toStore: '', reason: '' });
      } catch (error) {
        alert('Erreur: ' + error.message);
      }
    };

    if (!showTransferModal) return null;

    return (
      <div style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: 'rgba(0,0,0,0.5)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 1000
      }}>
        <div style={{
          background: isDark ? '#2d3748' : 'white',
          padding: '30px',
          borderRadius: '12px',
          width: '90%',
          maxWidth: '500px'
        }}>
          <h3 style={{ marginBottom: '20px', color: isDark ? '#f7fafc' : '#2d3748' }}>
            Transfert de Stock
          </h3>

          <div style={{ marginBottom: '15px' }}>
            <label style={{ display: 'block', marginBottom: '5px', color: isDark ? '#a0aec0' : '#64748b' }}>
              Produit
            </label>
            <select
              value={transferData.productId}
              onChange={(e) => setTransferData({...transferData, productId: e.target.value})}
              style={{
                width: '100%',
                padding: '10px',
                border: `1px solid ${isDark ? '#4a5568' : '#e2e8f0'}`,
                borderRadius: '6px',
                background: isDark ? '#374151' : 'white',
                color: isDark ? '#f7fafc' : '#2d3748'
              }}
            >
              <option value="">Sélectionner un produit</option>
              {globalProducts.map(product => (
                <option key={product.id} value={product.id}>
                  {product.name} (Stock: {product.stock})
                </option>
              ))}
            </select>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginBottom: '15px' }}>
            <div>
              <label style={{ display: 'block', marginBottom: '5px', color: isDark ? '#a0aec0' : '#64748b' }}>
                De (magasin source)
              </label>
              <select
                value={transferData.fromStore}
                onChange={(e) => setTransferData({...transferData, fromStore: e.target.value})}
                style={{
                  width: '100%',
                  padding: '10px',
                  border: `1px solid ${isDark ? '#4a5568' : '#e2e8f0'}`,
                  borderRadius: '6px',
                  background: isDark ? '#374151' : 'white',
                  color: isDark ? '#f7fafc' : '#2d3748'
                }}
              >
                <option value="">Magasin source</option>
                {stores.map(store => (
                  <option key={store.id} value={store.id}>{store.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label style={{ display: 'block', marginBottom: '5px', color: isDark ? '#a0aec0' : '#64748b' }}>
                Vers (magasin destination)
              </label>
              <select
                value={transferData.toStore}
                onChange={(e) => setTransferData({...transferData, toStore: e.target.value})}
                style={{
                  width: '100%',
                  padding: '10px',
                  border: `1px solid ${isDark ? '#4a5568' : '#e2e8f0'}`,
                  borderRadius: '6px',
                  background: isDark ? '#374151' : 'white',
                  color: isDark ? '#f7fafc' : '#2d3748'
                }}
              >
                <option value="">Magasin destination</option>
                {stores.map(store => (
                  <option key={store.id} value={store.id}>{store.name}</option>
                ))}
              </select>
            </div>
          </div>

          <div style={{ marginBottom: '15px' }}>
            <label style={{ display: 'block', marginBottom: '5px', color: isDark ? '#a0aec0' : '#64748b' }}>
              Quantité à transférer
            </label>
            <input
              type="number"
              value={transferData.quantity}
              onChange={(e) => setTransferData({...transferData, quantity: e.target.value})}
              min="1"
              style={{
                width: '100%',
                padding: '10px',
                border: `1px solid ${isDark ? '#4a5568' : '#e2e8f0'}`,
                borderRadius: '6px',
                background: isDark ? '#374151' : 'white',
                color: isDark ? '#f7fafc' : '#2d3748'
              }}
            />
          </div>

          <div style={{ marginBottom: '20px' }}>
            <label style={{ display: 'block', marginBottom: '5px', color: isDark ? '#a0aec0' : '#64748b' }}>
              Raison du transfert (optionnel)
            </label>
            <input
              type="text"
              value={transferData.reason}
              onChange={(e) => setTransferData({...transferData, reason: e.target.value})}
              placeholder="Ex: Réajustement de stock, demande client..."
              style={{
                width: '100%',
                padding: '10px',
                border: `1px solid ${isDark ? '#4a5568' : '#e2e8f0'}`,
                borderRadius: '6px',
                background: isDark ? '#374151' : 'white',
                color: isDark ? '#f7fafc' : '#2d3748'
              }}
            />
          </div>

          <div style={{ display: 'flex', gap: '10px' }}>
            <button
              onClick={() => setShowTransferModal(false)}
              style={{
                flex: 1,
                padding: '12px',
                background: '#64748b',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                cursor: 'pointer'
              }}
            >
              Annuler
            </button>
            <button
              onClick={handleTransfer}
              style={{
                flex: 1,
                padding: '12px',
                background: '#10b981',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                cursor: 'pointer',
                fontWeight: '600'
              }}
            >
              Transférer
            </button>
          </div>
        </div>
      </div>
    );
  };

  // Rendu conditionnel des modules
  const renderModule = () => {
    switch(activeModule) {
      case 'dashboard':
        return <DashboardModule />;
      case 'sales':
        return <SalesModule />;
      case 'stocks':
        return <InventoryModule />;
      case 'reports':
        return <ReportsModule />;
      case 'customers':
        return <CustomersModule />;
      case 'settings':
        return <SettingsModule />;
      case 'cash':
        return <CashRegisterModule />;
      case 'credits':
        return <CreditManagementModule />;
      default:
        return <DashboardModule />;
    }
  };

  // Page de connexion
  if (!isAuthenticated) {
    return (
      <div style={styles.container}>
        <div style={styles.loginBox}>
          <h1 style={styles.title}>
            POS Multi-Magasins
          </h1>
          <p style={styles.subtitle}>Système de Point de Vente</p>
          
          <div style={{ marginBottom: '20px' }}>
            <input 
              type="text" 
              placeholder="Nom d'utilisateur"
              style={{
                width: '100%',
                padding: '10px',
                marginBottom: '10px',
                border: `1px solid ${isDark ? '#4a5568' : '#e2e8f0'}`,
                borderRadius: '6px',
                fontSize: '14px',
                background: isDark ? '#374151' : 'white',
                color: isDark ? '#f7fafc' : '#2d3748'
              }}
            />
            <input 
              type="password" 
              placeholder="Mot de passe"
              style={{
                width: '100%',
                padding: '10px',
                border: `1px solid ${isDark ? '#4a5568' : '#e2e8f0'}`,
                borderRadius: '6px',
                fontSize: '14px',
                background: isDark ? '#374151' : 'white',
                color: isDark ? '#f7fafc' : '#2d3748'
              }}
            />
          </div>
          
          <button 
            style={styles.button}
            onClick={() => setIsAuthenticated(true)}
            onMouseOver={(e) => e.target.style.background = '#3182ce'}
            onMouseOut={(e) => e.target.style.background = '#4299e1'}
          >
            Se connecter
          </button>
          
          <div style={{ 
            marginTop: '20px', 
            padding: '15px', 
            background: isDark ? '#374151' : '#f7fafc', 
            borderRadius: '6px',
            fontSize: '12px',
            color: isDark ? '#cbd5e0' : '#4a5568'
          }}>
            <strong>Multi-Magasins:</strong><br/>
            Gérez Alimentation Wend-Kuuni et Wend-Yam<br/>
            Cliquez sur "Se connecter" pour accéder
          </div>
        </div>
      </div>
    );
  }

  // Application principale avec navigation
  return (
    <div style={styles.dashboard}>
      <header style={styles.header}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
          <h1 style={{ fontSize: '24px', fontWeight: 'bold', color: isDark ? '#f7fafc' : '#2d3748' }}>
            POS Multi-Magasins
          </h1>
          <StoreSelector />
        </div>
        
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          {viewMode === 'single' && getCurrentStore() && (
            <div style={{
              padding: '6px 12px',
              background: `${getCurrentStore().color}20`,
              color: getCurrentStore().color,
              borderRadius: '6px',
              fontSize: '12px',
              fontWeight: '600',
              border: `1px solid ${getCurrentStore().color}40`
            }}>
              {getCurrentStore().code}
            </div>
          )}
          
          <button 
            style={{
              padding: '8px 20px',
              background: '#f56565',
              color: 'white',
              border: 'none',
              borderRadius: '6px',
              cursor: 'pointer',
              fontSize: '14px',
              fontWeight: '600'
            }}
            onClick={() => {
              setIsAuthenticated(false);
              setActiveModule('dashboard');
            }}
          >
            Déconnexion
          </button>
        </div>
      </header>
      
      {/* Navigation */}
      {!isMobile && (
        <nav style={styles.nav}>
          <button
            style={{
              ...styles.navButton,
              ...(activeModule === 'dashboard' ? styles.navButtonActive : {})
            }}
            onClick={() => setActiveModule('dashboard')}
          >
            <Home size={18} />
            Tableau de bord
          </button>
          
          <button
            style={{
              ...styles.navButton,
              ...(activeModule === 'sales' ? styles.navButtonActive : {})
            }}
            onClick={() => setActiveModule('sales')}
          >
            <ShoppingCart size={18} />
            Ventes
          </button>
          
        
          <button
            style={{
              ...styles.navButton,
              ...(activeModule === 'stocks' ? styles.navButtonActive : {})
            }}
            onClick={() => setActiveModule('stocks')}
          >
            <Package size={18} />
            Stocks
          </button>
          
          <button
            style={{
              ...styles.navButton,
              ...(activeModule === 'customers' ? styles.navButtonActive : {})
            }}
            onClick={() => setActiveModule('customers')}
          >
            <Users size={18} />
            Clients
          </button>
          
          <button
            style={{
              ...styles.navButton,
              ...(activeModule === 'reports' ? styles.navButtonActive : {})
            }}
            onClick={() => setActiveModule('reports')}
          >
            <BarChart3 size={18} />
            Rapports
          </button>

          <button
            style={{
              ...styles.navButton,
              ...(activeModule === 'cash' ? styles.navButtonActive : {})
            }}
            onClick={() => setActiveModule('cash')}
          >
            <Calculator size={18} />
            Caisse
          </button>
          
          <button
            style={{
              ...styles.navButton,
              ...(activeModule === 'credits' ? styles.navButtonActive : {})
            }}
            onClick={() => setActiveModule('credits')}
          >
            <CreditCard size={18} />
            Crédits
          </button>

          <button
            style={{
              ...styles.navButton,
              ...(activeModule === 'settings' ? styles.navButtonActive : {})
            }}
            onClick={() => setActiveModule('settings')}
          >
            <Settings size={18} />
            Paramètres
          </button>
        </nav>
      )}
      
      <main style={styles.main}>
        {renderModule()}
      </main>

      {/* Navigation mobile */}
      <MobileNavigation 
        activeModule={activeModule}
        setActiveModule={setActiveModule}
        isDark={isDark}
      />

      {/* Modal de transfert */}
      <TransferStockModal />
    </div>
  );
}

export default App;