import React, { useState } from 'react';
import { Store, ChevronDown, BarChart3, ArrowUpDown, Bell, TrendingUp, Users, Package } from 'lucide-react';
import { useMultiStore } from '../contexts/MultiStoreContext';

const StoreSelector = () => {
  const {
    stores,
    currentStoreId,
    setCurrentStoreId,
    viewMode,
    setViewMode,
    getCurrentStore,
    getStoreStats,
    getConsolidatedData,
    getStoreComparison
  } = useMultiStore();

  const [showDropdown, setShowDropdown] = useState(false);
  const [showStoreStats, setShowStoreStats] = useState(false);

  const currentStore = getCurrentStore();
  const stats = getStoreStats(currentStoreId);

  const styles = {
    container: {
      display: 'flex',
      alignItems: 'center',
      gap: '10px',
      position: 'relative'
    },
    selectorButton: {
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      padding: '8px 16px',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      color: 'white',
      border: 'none',
      borderRadius: '8px',
      cursor: 'pointer',
      fontWeight: '600',
      fontSize: '14px',
      boxShadow: '0 4px 12px rgba(102, 126, 234, 0.4)',
      transition: 'all 0.3s ease',
      minWidth: '200px'
    },
    dropdown: {
      position: 'absolute',
      top: '100%',
      left: 0,
      right: 0,
      background: 'white',
      borderRadius: '8px',
      boxShadow: '0 10px 25px rgba(0,0,0,0.15)',
      zIndex: 1000,
      marginTop: '5px',
      overflow: 'hidden',
      border: '1px solid #e2e8f0'
    },
    storeOption: {
      display: 'flex',
      alignItems: 'center',
      gap: '12px',
      padding: '12px 16px',
      cursor: 'pointer',
      transition: 'background 0.2s',
      borderBottom: '1px solid #f1f5f9'
    },
    storeIndicator: {
      width: '12px',
      height: '12px',
      borderRadius: '50%',
      flexShrink: 0
    },
    storeInfo: {
      flex: 1
    },
    storeName: {
      fontWeight: '600',
      color: '#2d3748',
      fontSize: '14px'
    },
    storeCode: {
      fontSize: '12px',
      color: '#718096',
      marginTop: '2px'
    },
    viewModeButton: {
      display: 'flex',
      alignItems: 'center',
      gap: '4px',
      padding: '6px 12px',
      background: '#f7fafc',
      border: '1px solid #e2e8f0',
      borderRadius: '6px',
      cursor: 'pointer',
      fontSize: '12px',
      fontWeight: '600',
      color: '#4a5568',
      transition: 'all 0.2s'
    },
    statsButton: {
      display: 'flex',
      alignItems: 'center',
      gap: '4px',
      padding: '6px 12px',
      background: '#ebf8ff',
      border: '1px solid #90cdf4',
      borderRadius: '6px',
      cursor: 'pointer',
      fontSize: '12px',
      fontWeight: '600',
      color: '#2b6cb0',
      transition: 'all 0.2s'
    }
  };

  const handleStoreSelect = (store) => {
    setCurrentStoreId(store.id);
    setViewMode('single');
    setShowDropdown(false);
  };

  const handleViewModeToggle = () => {
    setViewMode(viewMode === 'single' ? 'consolidated' : 'single');
    setShowDropdown(false);
  };

  const toggleViewMode = () => {
    setViewMode(viewMode === 'single' ? 'consolidated' : 'single');
  };

  // Modal des statistiques comparatives
  const StoreStatsModal = () => {
    const comparison = getStoreComparison();
    const consolidatedData = getConsolidatedData();
    
    return (
      <div style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: 'rgba(0,0,0,0.5)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 1100
      }}>
        <div style={{
          background: 'white',
          borderRadius: '12px',
          padding: '30px',
          width: '90%',
          maxWidth: '800px',
          maxHeight: '80vh',
          overflowY: 'auto'
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '25px' }}>
            <h2 style={{ fontSize: '24px', fontWeight: 'bold', color: '#2d3748' }}>
              Statistiques Comparatives
            </h2>
            <button
              onClick={() => setShowStoreStats(false)}
              style={{
                background: '#f56565',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                padding: '8px 16px',
                cursor: 'pointer',
                fontWeight: '600'
              }}
            >
              Fermer
            </button>
          </div>

          {/* Résumé global */}
          <div style={{
            background: '#f7fafc',
            padding: '20px',
            borderRadius: '8px',
            marginBottom: '25px'
          }}>
            <h3 style={{ fontSize: '18px', fontWeight: '600', marginBottom: '15px', color: '#2d3748' }}>
              Vue d'Ensemble Consolidée
            </h3>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', gap: '15px' }}>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#3182ce' }}>
                  {consolidatedData.sales.reduce((sum, s) => sum + s.total, 0).toLocaleString()} FCFA
                </div>
                <div style={{ fontSize: '12px', color: '#718096' }}>CA Total</div>
              </div>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#38a169' }}>
                  {consolidatedData.products.length}
                </div>
                <div style={{ fontSize: '12px', color: '#718096' }}>Produits Total</div>
              </div>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#d69e2e' }}>
                  {consolidatedData.customers.length}
                </div>
                <div style={{ fontSize: '12px', color: '#718096' }}>Clients Uniques</div>
              </div>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: '24px', fontWeight: 'bold', color: '#e53e3e' }}>
                  {consolidatedData.credits.filter(c => c.status !== 'paid').length}
                </div>
                <div style={{ fontSize: '12px', color: '#718096' }}>Crédits Actifs</div>
              </div>
            </div>
          </div>

          {/* Comparaison par magasin */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(350px, 1fr))', gap: '20px' }}>
            {comparison.map((store, index) => (
              <div
                key={store.id}
                style={{
                  border: `2px solid ${store.color}`,
                  borderRadius: '12px',
                  padding: '20px',
                  position: 'relative',
                  background: index === 0 ? '#f0fff4' : 'white'
                }}
              >
                {index === 0 && (
                  <div style={{
                    position: 'absolute',
                    top: '-10px',
                    right: '20px',
                    background: '#38a169',
                    color: 'white',
                    padding: '4px 12px',
                    borderRadius: '12px',
                    fontSize: '12px',
                    fontWeight: 'bold'
                  }}>
                    🏆 Top Performer
                  </div>
                )}

                <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '15px' }}>
                  <div style={{ 
                    width: '16px', 
                    height: '16px', 
                    borderRadius: '50%', 
                    background: store.color 
                  }} />
                  <div>
                    <h4 style={{ fontSize: '16px', fontWeight: 'bold', color: '#2d3748', margin: 0 }}>
                      {store.name}
                    </h4>
                    <p style={{ fontSize: '12px', color: '#718096', margin: 0 }}>
                      {store.manager} • {store.code}
                    </p>
                  </div>
                </div>

                <div style={styles.metricRow}>
                  <span style={styles.metricLabel}>💰 CA du Mois</span>
                  <span style={styles.metricValue}>
                    {(store.stats?.monthRevenue || 0).toLocaleString()} FCFA
                  </span>
                </div>

                <div style={styles.metricRow}>
                  <span style={styles.metricLabel}>📈 CA Aujourd'hui</span>
                  <span style={styles.metricValue}>
                    {(store.stats?.todayRevenue || 0).toLocaleString()} FCFA
                  </span>
                </div>

                <div style={styles.metricRow}>
                  <span style={styles.metricLabel}>📦 Produits</span>
                  <span style={styles.metricValue}>{store.stats?.totalProducts || 0}</span>
                </div>

                <div style={styles.metricRow}>
                  <span style={styles.metricLabel}>👥 Clients</span>
                  <span style={styles.metricValue}>{store.stats?.totalCustomers || 0}</span>
                </div>

                <div style={styles.metricRow}>
                  <span style={styles.metricLabel}>⚠️ Alertes Stock</span>
                  <span style={{ 
                    ...styles.metricValue, 
                    color: (store.stats?.lowStockCount || 0) > 0 ? '#e53e3e' : '#38a169' 
                  }}>
                    {(store.stats?.lowStockCount || 0) + (store.stats?.outOfStockCount || 0)}
                  </span>
                </div>

                
                <div style={styles.metricRow}>
                  <span style={styles.metricLabel}>💳 Crédits En Cours</span>
                  <span style={styles.metricValue}>
                    {(store.stats?.creditsAmount || 0).toLocaleString()} FCFA
                  </span>
                </div>

                {/* Indicateur de performance */}
                <div style={{
                  marginTop: '15px',
                  padding: '10px',
                  background: (store.stats?.monthRevenue || 0) > (consolidatedData.sales.reduce((sum, s) => sum + s.total, 0) / stores.length) ? '#f0fdf4' : '#fffbeb',
                  borderRadius: '6px',
                  textAlign: 'center'
                }}>
                  <div style={{
                    fontSize: '12px',
                    color: (store.stats?.monthRevenue || 0) > (consolidatedData.sales.reduce((sum, s) => sum + s.total, 0) / stores.length) ? '#166534' : '#d97706',
                    fontWeight: '600'
                  }}>
                    {(store.stats?.monthRevenue || 0) > (consolidatedData.sales.reduce((sum, s) => sum + s.total, 0) / stores.length) ? 
                      '📈 Performance Supérieure' : 
                      '📊 Performance Standard'
                    }
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Conseils */}
          <div style={{
            marginTop: '20px',
            padding: '15px',
            background: '#fefce8',
            borderRadius: '8px',
            border: '1px solid #fde047'
          }}>
            <h4 style={{ color: '#a16207', marginBottom: '8px' }}>💡 Conseils de Gestion</h4>
            <ul style={{ fontSize: '12px', color: '#a16207', paddingLeft: '20px' }}>
              <li>Transférez les stocks entre magasins pour optimiser les ventes</li>
              <li>Analysez les produits performants de chaque magasin</li>
              <li>Surveillez les alertes stock pour éviter les ruptures</li>
              <li>Fidélisez les clients avec des programmes personnalisés</li>
            </ul>
          </div>
        </div>
      </div>
    );
  };

  // Ajout des styles manquants
  styles.metricRow = {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '8px',
    padding: '4px 0'
  };

  styles.metricLabel = {
    fontSize: '13px',
    color: '#718096'
  };

  styles.metricValue = {
    fontSize: '14px',
    fontWeight: '600',
    color: '#2d3748'
  };

  return (
    <>
      <div style={styles.container}>
        {/* Sélecteur principal */}
        <div style={{ position: 'relative' }}>
          <button
            style={styles.selectorButton}
            onClick={() => setShowDropdown(!showDropdown)}
            onMouseOver={(e) => e.target.style.transform = 'scale(1.02)'}
            onMouseOut={(e) => e.target.style.transform = 'scale(1)'}
          >
            <Store size={16} />
            <span>
              {viewMode === 'single' ? currentStore?.name : 'Vue Consolidée'}
            </span>
            <ChevronDown size={14} />
          </button>

          {showDropdown && (
            <div style={styles.dropdown}>
              {/* Options des magasins individuels */}
              {stores.map(store => (
                <div
                  key={store.id}
                  style={{
                    ...styles.storeOption,
                    background: currentStore?.id === store.id && viewMode === 'single' ? '#f8fafc' : 'white'
                  }}
                  onClick={() => handleStoreSelect(store)}
                  onMouseOver={(e) => e.target.style.background = '#f1f5f9'}
                  onMouseOut={(e) => e.target.style.background = 
                    currentStore?.id === store.id && viewMode === 'single' ? '#f8fafc' : 'white'
                  }
                >
                  <div style={{ ...styles.storeIndicator, background: store.color }} />
                  <div style={styles.storeInfo}>
                    <div style={styles.storeName}>{store.name}</div>
                    <div style={styles.storeCode}>Code: {store.code} • {store.manager}</div>
                  </div>
                  {currentStore?.id === store.id && viewMode === 'single' && (
                    <div style={{ color: store.color, fontWeight: 'bold' }}>✓</div>
                  )}
                </div>
              ))}

              {/* Séparateur */}
              <div style={{ height: '1px', background: '#e2e8f0', margin: '5px 0' }} />

              {/* Vue consolidée */}
              <div
                style={{
                  ...styles.storeOption,
                  background: viewMode === 'consolidated' ? '#f8fafc' : 'white'
                }}
                onClick={handleViewModeToggle}
                onMouseOver={(e) => e.target.style.background = '#f1f5f9'}
                onMouseOut={(e) => e.target.style.background = 
                  viewMode === 'consolidated' ? '#f8fafc' : 'white'
                }
              >
                <BarChart3 size={16} color="#6366f1" />
                <div style={styles.storeInfo}>
                  <div style={styles.storeName}>Vue Consolidée</div>
                  <div style={styles.storeCode}>Tous les magasins • Analyse globale</div>
                </div>
                {viewMode === 'consolidated' && (
                  <div style={{ color: '#6366f1', fontWeight: 'bold' }}>✓</div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Bouton vue mode rapide */}
        <button
          style={styles.viewModeButton}
          onClick={toggleViewMode}
          title={viewMode === 'single' ? 'Voir tous les magasins' : 'Voir un magasin'}
        >
          <ArrowUpDown size={14} />
          {viewMode === 'single' ? 'Global' : 'Simple'}
        </button>

        {/* Bouton statistiques comparatives */}
        <button
          style={styles.statsButton}
          onClick={() => setShowStoreStats(true)}
          title="Statistiques comparatives"
        >
          <BarChart3 size={14} />
          Stats
        </button>

        {/* Indicateur d'alertes */}
        {(stats?.lowStockCount > 0 || stats?.outOfStockCount > 0) && (
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '4px',
            padding: '4px 8px',
            background: '#fef2f2',
            color: '#dc2626',
            borderRadius: '6px',
            fontSize: '12px',
            fontWeight: '600'
          }}>
            <Bell size={12} />
            {(stats?.lowStockCount || 0) + (stats?.outOfStockCount || 0)}
          </div>
        )}
      </div>

      {/* Modal des statistiques */}
      {showStoreStats && <StoreStatsModal />}
    </>
  );
};

export default StoreSelector;