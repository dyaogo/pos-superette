import React, { createContext, useContext, useState, useEffect } from 'react';

const MultiStoreContext = createContext();

export const MultiStoreProvider = ({ children }) => {
  // Configuration des magasins
  const [stores] = useState([
    {
      id: 'wend-kuuni',
      name: 'Alimentation Wend-Kuuni',
      code: 'WK001',
      address: 'Secteur 15, Ouagadougou',
      manager: 'Ibrahim Ouedraogo',
      phone: '+226 70 12 34 56',
      color: '#3b82f6',
      isActive: true,
      openingHours: '06:00 - 22:00',
      currency: 'FCFA'
    },
    {
      id: 'wend-yam',
      name: 'Alimentation Wend-Yam',
      code: 'WY002', 
      address: 'Zone du Bois, Ouagadougou',
      manager: 'Fatoumata Kone',
      phone: '+226 70 65 43 21',
      color: '#10b981',
      isActive: true,
      openingHours: '06:30 - 21:30',
      currency: 'FCFA'
    }
  ]);

  // Magasin actuellement sélectionné
  const [currentStoreId, setCurrentStoreId] = useState('wend-kuuni');
  const [viewMode, setViewMode] = useState('single'); // 'single' ou 'consolidated'

  // Données par magasin (structure séparée)
  const [storeData, setStoreData] = useState({
    'wend-kuuni': {
      products: [],
      sales: [],
      customers: [{ id: 1, name: 'Client Comptant', phone: '', email: '', totalPurchases: 0, points: 0 }],
      credits: [],
      settings: {
        storeName: 'Alimentation Wend-Kuuni',
        currency: 'FCFA',
        taxRate: 18,
        pointsPerPurchase: 1,
        darkMode: false
      }
    },
    'wend-yam': {
      products: [],
      sales: [],
      customers: [{ id: 1, name: 'Client Comptant', phone: '', email: '', totalPurchases: 0, points: 0 }],
      credits: [],
      settings: {
        storeName: 'Alimentation Wend-Yam',
        currency: 'FCFA',
        taxRate: 18,
        pointsPerPurchase: 1,
        darkMode: false
      }
    }
  });

  // Chargement des données depuis localStorage
  useEffect(() => {
    stores.forEach(store => {
      const storeKey = `pos_${store.id}`;
      const savedData = {
        products: JSON.parse(localStorage.getItem(`${storeKey}_products`) || '[]'),
        sales: JSON.parse(localStorage.getItem(`${storeKey}_sales`) || '[]'),
        customers: JSON.parse(localStorage.getItem(`${storeKey}_customers`) || '[{"id":1,"name":"Client Comptant","phone":"","email":"","totalPurchases":0,"points":0}]'),
        credits: JSON.parse(localStorage.getItem(`${storeKey}_credits`) || '[]'),
        settings: JSON.parse(localStorage.getItem(`${storeKey}_settings`) || `{"storeName":"${store.name}","currency":"FCFA","taxRate":18,"pointsPerPurchase":1,"darkMode":false}`)
      };

      if (savedData.products.length > 0 || savedData.sales.length > 0) {
        setStoreData(prev => ({
          ...prev,
          [store.id]: savedData
        }));
      }
    });

    // Charger le magasin sélectionné
    const savedStoreId = localStorage.getItem('pos_current_store');
    if (savedStoreId && stores.find(s => s.id === savedStoreId)) {
      setCurrentStoreId(savedStoreId);
    }
  }, [stores]);

  // Sauvegarde automatique des données
  useEffect(() => {
    Object.keys(storeData).forEach(storeId => {
      const storeKey = `pos_${storeId}`;
      const data = storeData[storeId];
      
      localStorage.setItem(`${storeKey}_products`, JSON.stringify(data.products));
      localStorage.setItem(`${storeKey}_sales`, JSON.stringify(data.sales));
      localStorage.setItem(`${storeKey}_customers`, JSON.stringify(data.customers));
      localStorage.setItem(`${storeKey}_credits`, JSON.stringify(data.credits));
      localStorage.setItem(`${storeKey}_settings`, JSON.stringify(data.settings));
    });
  }, [storeData]);

  // Sauvegarde du magasin sélectionné
  useEffect(() => {
    localStorage.setItem('pos_current_store', currentStoreId);
  }, [currentStoreId]);

  // Getters pour le magasin actuel
  const getCurrentStore = () => stores.find(s => s.id === currentStoreId);
  const getCurrentStoreData = () => storeData[currentStoreId] || {
    products: [],
    sales: [],
    customers: [{ id: 1, name: 'Client Comptant', phone: '', email: '', totalPurchases: 0, points: 0 }],
    credits: [],
    settings: { storeName: '', currency: 'FCFA', taxRate: 18, pointsPerPurchase: 1, darkMode: false }
  };

  // Mise à jour des données du magasin actuel
  const updateCurrentStoreData = (key, data) => {
    setStoreData(prev => ({
      ...prev,
      [currentStoreId]: {
        ...prev[currentStoreId],
        [key]: data
      }
    }));
  };

  // Transfert de stock entre magasins
  const transferStock = (productId, quantity, fromStoreId, toStoreId, reason = 'Transfert entre magasins') => {
    const fromStore = storeData[fromStoreId];
    const toStore = storeData[toStoreId];
    
    const fromProduct = fromStore.products.find(p => p.id === productId);
    if (!fromProduct || fromProduct.stock < quantity) {
      throw new Error('Stock insuffisant pour le transfert');
    }

    // Réduire le stock du magasin source
    const updatedFromProducts = fromStore.products.map(p => 
      p.id === productId ? { ...p, stock: p.stock - quantity } : p
    );

    // Augmenter le stock du magasin destination
    let updatedToProducts = [...toStore.products];
    const toProductIndex = updatedToProducts.findIndex(p => p.id === productId);
    
    if (toProductIndex >= 0) {
      updatedToProducts[toProductIndex] = {
        ...updatedToProducts[toProductIndex],
        stock: updatedToProducts[toProductIndex].stock + quantity
      };
    } else {
      // Ajouter le produit s'il n'existe pas dans le magasin destination
      updatedToProducts.push({ ...fromProduct, stock: quantity });
    }

    // Mettre à jour les données
    setStoreData(prev => ({
      ...prev,
      [fromStoreId]: { ...prev[fromStoreId], products: updatedFromProducts },
      [toStoreId]: { ...prev[toStoreId], products: updatedToProducts }
    }));

    // Enregistrer le transfert dans l'historique
    const transfer = {
      id: Date.now(),
      date: new Date().toISOString(),
      productId,
      productName: fromProduct.name,
      quantity,
      fromStore: fromStoreId,
      toStore: toStoreId,
      reason,
      type: 'transfer'
    };

    // Optionnel: Enregistrer l'historique des transferts
    const transfers = JSON.parse(localStorage.getItem('pos_transfers') || '[]');
    transfers.push(transfer);
    localStorage.setItem('pos_transfers', JSON.stringify(transfers));

    return transfer;
  };

  // Données consolidées (tous magasins)
  const getConsolidatedData = () => {
    const allProducts = [];
    const allSales = [];
    const allCustomers = [];
    const allCredits = [];
    
    Object.keys(storeData).forEach(storeId => {
      const data = storeData[storeId];
      
      // Produits avec identifiant de magasin
      allProducts.push(...data.products.map(p => ({ ...p, storeId })));
      
      // Ventes avec identifiant de magasin
      allSales.push(...data.sales.map(s => ({ ...s, storeId })));
      
      // Clients (éviter les doublons)
      data.customers.forEach(c => {
        if (c.id !== 1 && !allCustomers.find(ac => ac.phone === c.phone && c.phone)) {
          allCustomers.push({ ...c, storeId });
        }
      });
      
      // Crédits avec identifiant de magasin
      allCredits.push(...data.credits.map(c => ({ ...c, storeId })));
    });

    return {
      products: allProducts,
      sales: allSales,
      customers: allCustomers,
      credits: allCredits
    };
  };

  // Statistiques par magasin
  const getStoreStats = (storeId) => {
    const data = storeData[storeId];
    if (!data) return null;

    const today = new Date().toDateString();
    const todaySales = data.sales.filter(sale => 
      new Date(sale.date).toDateString() === today
    );
    
    const thisMonth = new Date().getMonth();
    const monthSales = data.sales.filter(sale => 
      new Date(sale.date).getMonth() === thisMonth
    );

    return {
      todayRevenue: todaySales.reduce((sum, sale) => sum + sale.total, 0),
      todayTransactions: todaySales.length,
      monthRevenue: monthSales.reduce((sum, sale) => sum + sale.total, 0),
      monthTransactions: monthSales.length,
      totalProducts: data.products.length,
      lowStockCount: data.products.filter(p => p.stock <= p.minStock).length,
      outOfStockCount: data.products.filter(p => p.stock === 0).length,
      totalCustomers: data.customers.length - 1,
      inventoryValue: data.products.reduce((sum, p) => sum + (p.stock * p.costPrice), 0),
      creditsAmount: data.credits.filter(c => c.status === 'pending' || c.status === 'partial')
        .reduce((sum, c) => sum + c.remainingAmount, 0)
    };
  };

  // Comparaison des performances
  const getStoreComparison = () => {
    const comparison = stores.map(store => {
      const stats = getStoreStats(store.id);
      return {
        ...store,
        stats
      };
    });

    return comparison.sort((a, b) => (b.stats?.monthRevenue || 0) - (a.stats?.monthRevenue || 0));
  };

  // Synchronisation des produits entre magasins
  const syncProductsToStore = (products, targetStoreId) => {
    const currentProducts = storeData[targetStoreId].products;
    
    const syncedProducts = products.map(newProduct => {
      const existingProduct = currentProducts.find(p => p.sku === newProduct.sku);
      if (existingProduct) {
        // Mettre à jour les informations mais garder le stock local
        return { ...newProduct, id: existingProduct.id, stock: existingProduct.stock };
      }
      return { ...newProduct, id: Date.now() + Math.random(), stock: 0 };
    });

    setStoreData(prev => ({
      ...prev,
      [targetStoreId]: {
        ...prev[targetStoreId],
        products: syncedProducts
      }
    }));
  };

  const value = {
    // États
    stores,
    currentStoreId,
    setCurrentStoreId,
    viewMode,
    setViewMode,
    storeData,
    setStoreData,
    
    // Getters
    getCurrentStore,
    getCurrentStoreData,
    getConsolidatedData,
    getStoreStats,
    getStoreComparison,
    
    // Actions
    updateCurrentStoreData,
    transferStock,
    syncProductsToStore,
    
    // Données du magasin actuel (pour compatibilité avec l'existant)
    globalProducts: getCurrentStoreData().products,
    setGlobalProducts: (products) => updateCurrentStoreData('products', products),
    salesHistory: getCurrentStoreData().sales,
    setSalesHistory: (sales) => updateCurrentStoreData('sales', sales),
    customers: getCurrentStoreData().customers,
    setCustomers: (customers) => updateCurrentStoreData('customers', customers),
    credits: getCurrentStoreData().credits,
    setCredits: (credits) => updateCurrentStoreData('credits', credits),
    appSettings: getCurrentStoreData().settings,
    setAppSettings: (settings) => updateCurrentStoreData('settings', settings),
    
    // Fonctions existantes adaptées
    processSale: (cart, paymentMethod, amountReceived, customerId = 1) => {
      const sale = {
        id: Date.now(),
        date: new Date().toISOString(),
        items: cart,
        total: cart.reduce((sum, item) => sum + (item.price * item.quantity), 0),
        paymentMethod,
        amountReceived,
        change: paymentMethod === 'cash' ? amountReceived - cart.reduce((sum, item) => sum + (item.price * item.quantity), 0) : 0,
        customerId,
        receiptNumber: `${getCurrentStore()?.code || 'POS'}${Date.now().toString().slice(-8)}`,
        storeId: currentStoreId
      };

      // Déduire du stock
      const currentData = getCurrentStoreData();
      const updatedProducts = currentData.products.map(product => {
        const cartItem = cart.find(item => item.id === product.id);
        if (cartItem) {
          return {
            ...product,
            stock: Math.max(0, product.stock - cartItem.quantity)
          };
        }
        return product;
      });

      updateCurrentStoreData('products', updatedProducts);
      updateCurrentStoreData('sales', [sale, ...currentData.sales]);

      // Mettre à jour les points du client
      if (customerId !== 1) {
        const pointsEarned = Math.floor(sale.total / 1000);
        const updatedCustomers = currentData.customers.map(c => 
          c.id === customerId 
            ? { ...c, totalPurchases: c.totalPurchases + sale.total, points: c.points + pointsEarned }
            : c
        );
        updateCurrentStoreData('customers', updatedCustomers);
      }

      return sale;
    },

    addStock: (productId, quantity, reason = 'Réapprovisionnement') => {
      const currentData = getCurrentStoreData();
      const updatedProducts = currentData.products.map(product =>
        product.id === productId
          ? { ...product, stock: product.stock + quantity }
          : product
      );
      updateCurrentStoreData('products', updatedProducts);
    },

    getStats: () => getStoreStats(currentStoreId) || {
      todayRevenue: 0, todayTransactions: 0, monthRevenue: 0, monthTransactions: 0,
      totalProducts: 0, lowStockCount: 0, outOfStockCount: 0, totalCustomers: 0, inventoryValue: 0
    },

    addCredit: (customerId, amount, description) => {
      const credit = {
        id: Date.now(),
        customerId,
        amount,
        originalAmount: amount,
        description: description || 'Vente à crédit',
        createdAt: new Date().toISOString(),
        dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        status: 'pending',
        payments: [],
        remainingAmount: amount,
        storeId: currentStoreId
      };
      
      const currentData = getCurrentStoreData();
      updateCurrentStoreData('credits', [...currentData.credits, credit]);
      return credit;
    },

    clearAllData: () => {
      if (window.confirm('⚠️ ATTENTION: Ceci effacera TOUTES les données de TOUS les magasins. Êtes-vous sûr?')) {
        // Effacer les données de tous les magasins
        stores.forEach(store => {
          const storeKey = `pos_${store.id}`;
          localStorage.removeItem(`${storeKey}_products`);
          localStorage.removeItem(`${storeKey}_sales`);
          localStorage.removeItem(`${storeKey}_customers`);
          localStorage.removeItem(`${storeKey}_credits`);
          localStorage.removeItem(`${storeKey}_settings`);
        });
        localStorage.removeItem('pos_transfers');
        localStorage.removeItem('pos_current_store');
        window.location.reload();
      }
    }
  };

  return (
    <MultiStoreContext.Provider value={value}>
      {children}
    </MultiStoreContext.Provider>
  );
};

export const useMultiStore = () => {
  const context = useContext(MultiStoreContext);
  if (!context) {
    throw new Error('useMultiStore must be used within MultiStoreProvider');
  }
  return context;
};