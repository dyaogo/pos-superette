import React, { useState, useMemo } from 'react';
import { 
  TrendingUp, TrendingDown, DollarSign, Package, Users, ShoppingCart, 
  AlertTriangle, BarChart3, Clock, Target, Eye, Bell, Calendar, 
  ArrowUp, ArrowDown, Activity, Settings, Sun, Moon, Database
} from 'lucide-react';
import { useMultiStore } from '../../contexts/MultiStoreContext';
import { CloudSyncPanel } from '../../services/CloudSyncService';

const DashboardModule = () => {
  const { globalProducts, customers, salesHistory, appSettings, setAppSettings, getStats, clearAllData, credits } = useMultiStore();
  const [selectedPeriod, setSelectedPeriod] = useState('today');
  const [showDataManager, setShowDataManager] = useState(false);
  const [showAlerts, setShowAlerts] = useState(true);
  
  const isDark = appSettings.darkMode;
  const stats = getStats(); // Utilise la fonction existante

  // Calculs avancés pour les métriques comparatives
  const dashboardMetrics = useMemo(() => {
    const now = new Date();
    
    // Définir les périodes
    const periods = {
      today: { start: new Date(now.setHours(0,0,0,0)), label: "Aujourd'hui" },
      week: { start: new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000), label: "7 derniers jours" },
      month: { start: new Date(now.getFullYear(), now.getMonth(), 1), label: "Ce mois" },
      year: { start: new Date(now.getFullYear(), 0, 1), label: "Cette année" }
    };
    
    const currentPeriod = periods[selectedPeriod];
    const currentSales = salesHistory.filter(s => new Date(s.date) >= currentPeriod.start);
    
    // Période précédente pour comparaison
    const periodDuration = now.getTime() - currentPeriod.start.getTime();
    const previousPeriodStart = new Date(currentPeriod.start.getTime() - periodDuration);
    const previousSales = salesHistory.filter(s => 
      new Date(s.date) >= previousPeriodStart && new Date(s.date) < currentPeriod.start
    );
    
    // Calculs
    const currentRevenue = currentSales.reduce((sum, s) => sum + s.total, 0);
    const previousRevenue = previousSales.reduce((sum, s) => sum + s.total, 0);
    const revenueGrowth = previousRevenue > 0 ? 
      ((currentRevenue - previousRevenue) / previousRevenue * 100) : 0;
    
    const currentTransactions = currentSales.length;
    const previousTransactions = previousSales.length;
    const transactionGrowth = previousTransactions > 0 ? 
      ((currentTransactions - previousTransactions) / previousTransactions * 100) : 0;
    
    // Top produits de la période
    const productSales = {};
    currentSales.forEach(sale => {
      sale.items.forEach(item => {
        if (!productSales[item.id]) {
          productSales[item.id] = { ...item, totalSold: 0, totalRevenue: 0 };
        }
        productSales[item.id].totalSold += item.quantity;
        productSales[item.id].totalRevenue += item.quantity * item.price;
      });
    });
    
    const topProducts = Object.values(productSales)
      .sort((a, b) => b.totalRevenue - a.totalRevenue)
      .slice(0, 5);

    // Ventes par heure pour aujourd'hui
    const hourlyData = Array.from({length: 24}, (_, hour) => {
      const hourSales = selectedPeriod === 'today' ? currentSales.filter(sale => {
        const saleHour = new Date(sale.date).getHours();
        return saleHour === hour;
      }) : [];
      
      return {
        hour,
        sales: hourSales.reduce((sum, s) => sum + s.total, 0),
        transactions: hourSales.length
      };
    });
    
    return {
      currentRevenue,
      revenueGrowth,
      currentTransactions,
      transactionGrowth,
      topProducts,
      hourlyData,
      periodLabel: currentPeriod.label
    };
  }, [salesHistory, selectedPeriod]);

  const styles = {
    container: {
      padding: '20px',
      background: isDark ? '#1a202c' : '#f7fafc',
      minHeight: 'calc(100vh - 120px)'
    },
    header: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: '25px',
      flexWrap: 'wrap',
      gap: '15px'
    },
    headerControls: {
      display: 'flex',
      gap: '10px',
      alignItems: 'center',
      flexWrap: 'wrap'
    },
    periodSelector: {
      display: 'flex',
      gap: '4px',
      background: isDark ? '#2d3748' : 'white',
      padding: '4px',
      borderRadius: '8px',
      boxShadow: '0 1px 3px rgba(0,0,0,0.1)'
    },
    periodButton: {
      padding: '8px 12px',
      border: 'none',
      borderRadius: '6px',
      cursor: 'pointer',
      fontSize: '12px',
      fontWeight: '600',
      transition: 'all 0.2s'
    },
    metricsGrid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
      gap: '20px',
      marginBottom: '25px'
    },
    metricCard: {
      background: isDark ? '#2d3748' : 'white',
      padding: '20px',
      borderRadius: '12px',
      boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
      border: `1px solid ${isDark ? '#374151' : '#e2e8f0'}`
    },
    chartsGrid: {
      display: 'grid',
      gridTemplateColumns: 'minmax(0, 2fr) minmax(0, 1fr)',
      gap: '20px',
      marginBottom: '25px'
    },
    alertCard: {
      background: isDark ? '#431018' : '#fef2f2',
      border: `1px solid ${isDark ? '#7f1d1d' : '#fecaca'}`,
      borderRadius: '8px',
      padding: '15px',
      marginBottom: '15px',
      display: 'flex',
      alignItems: 'flex-start',
      gap: '12px'
    }
  };

  const MetricCard = ({ title, value, change, icon: Icon, color, format = 'number' }) => {
    const isPositive = change >= 0;
    const formattedValue = format === 'currency' ? 
      `${value.toLocaleString()} ${appSettings.currency}` : 
      value.toLocaleString();

    return (
      <div style={styles.metricCard}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px' }}>
          <div style={{
            width: '40px',
            height: '40px',
            borderRadius: '8px',
            background: `${color}20`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}>
            <Icon size={20} color={color} />
          </div>
          {change !== 0 && (
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '4px',
              color: isPositive ? '#10b981' : '#ef4444',
              fontSize: '12px',
              fontWeight: '600'
            }}>
              {isPositive ? <ArrowUp size={14} /> : <ArrowDown size={14} />}
              {Math.abs(change).toFixed(1)}%
            </div>
          )}
        </div>
        
        <div style={{ fontSize: '24px', fontWeight: 'bold', color: isDark ? '#f7fafc' : '#2d3748', marginBottom: '4px' }}>
          {formattedValue}
        </div>
        
        <div style={{ fontSize: '14px', color: isDark ? '#a0aec0' : '#64748b' }}>
          {title}
        </div>
      </div>
    );
  };

  const HourlyChart = () => {
    if (selectedPeriod !== 'today') {
      return (
        <div style={styles.metricCard}>
          <h3 style={{ fontSize: '18px', fontWeight: 'bold', marginBottom: '20px', color: isDark ? '#f7fafc' : '#2d3748' }}>
            Analyse par Heure
          </h3>
          <div style={{ textAlign: 'center', color: isDark ? '#a0aec0' : '#64748b', padding: '40px' }}>
            <Clock size={32} />
            <p style={{ marginTop: '10px' }}>Sélectionnez "Aujourd'hui" pour voir le détail par heure</p>
          </div>
        </div>
      );
    }

    const maxSales = Math.max(...dashboardMetrics.hourlyData.map(h => h.sales), 1);
    
    return (
      <div style={styles.metricCard}>
        <h3 style={{ fontSize: '18px', fontWeight: 'bold', marginBottom: '20px', color: isDark ? '#f7fafc' : '#2d3748' }}>
          Ventes par Heure - {dashboardMetrics.periodLabel}
        </h3>
        
        <div style={{ display: 'flex', alignItems: 'flex-end', gap: '2px', height: '150px', marginBottom: '10px' }}>
          {dashboardMetrics.hourlyData.map(({ hour, sales, transactions }) => {
            const height = (sales / maxSales) * 100;
            
            return (
              <div key={hour} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                <div
                  style={{
                    width: '100%',
                    background: sales > 0 ? '#3b82f6' : isDark ? '#374151' : '#e2e8f0',
                    height: `${Math.max(height, 2)}%`,
                    borderRadius: '2px 2px 0 0',
                    transition: 'all 0.3s',
                    cursor: 'pointer'
                  }}
                  title={`${hour}h: ${sales.toLocaleString()} ${appSettings.currency} (${transactions} ventes)`}
                />
                <div style={{ 
                  fontSize: '9px', 
                  color: isDark ? '#a0aec0' : '#64748b',
                  marginTop: '4px'
                }}>
                  {hour % 6 === 0 ? `${hour}h` : ''}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  const TopProductsWidget = () => (
    <div style={styles.metricCard}>
      <h3 style={{ fontSize: '18px', fontWeight: 'bold', marginBottom: '20px', color: isDark ? '#f7fafc' : '#2d3748' }}>
        Top Produits - {dashboardMetrics.periodLabel}
      </h3>
      
      {dashboardMetrics.topProducts.length === 0 ? (
        <div style={{ textAlign: 'center', color: isDark ? '#a0aec0' : '#64748b', padding: '20px' }}>
          <Package size={32} />
          <p style={{ marginTop: '10px' }}>Aucune vente dans cette période</p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
          {dashboardMetrics.topProducts.map((product, index) => (
            <div key={product.id || index} style={{
              display: 'flex',
              alignItems: 'center',
              gap: '10px',
              padding: '8px',
              background: isDark ? '#374151' : '#f8fafc',
              borderRadius: '6px'
            }}>
              <div style={{
                width: '24px',
                height: '24px',
                borderRadius: '50%',
                background: index === 0 ? '#fbbf24' : index === 1 ? '#94a3b8' : '#d1d5db',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '10px',
                fontWeight: 'bold',
                color: 'white'
              }}>
                {index + 1}
              </div>
              
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: '600', color: isDark ? '#f7fafc' : '#2d3748', fontSize: '14px' }}>
                  {product.name}
                </div>
                <div style={{ fontSize: '11px', color: isDark ? '#a0aec0' : '#64748b' }}>
                  {product.totalSold} vendus
                </div>
              </div>
              
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontWeight: 'bold', color: '#3b82f6', fontSize: '14px' }}>
                  {product.totalRevenue.toLocaleString()}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  const AlertsWidget = () => {
    const lowStockProducts = globalProducts.filter(p => p.stock > 0 && p.stock <= p.minStock);
    const outOfStockProducts = globalProducts.filter(p => p.stock === 0);
    const overdueCredits = credits?.filter(c => {
      const dueDate = new Date(c.dueDate);
      return (c.status === 'pending' || c.status === 'partial') && dueDate < new Date();
    }) || [];

    const alerts = [];
    
    if (outOfStockProducts.length > 0) {
      alerts.push({
        type: 'error',
        icon: AlertTriangle,
        title: 'Ruptures de Stock',
        message: `${outOfStockProducts.length} produit(s) en rupture`,
        action: 'Voir Stocks'
      });
    }
    
    if (lowStockProducts.length > 0) {
      alerts.push({
        type: 'warning',
        icon: Package,
        title: 'Stock Faible',
        message: `${lowStockProducts.length} produit(s) en stock faible`,
        action: 'Réapprovisionner'
      });
    }
    
    if (overdueCredits.length > 0) {
      alerts.push({
        type: 'error',
        icon: Clock,
        title: 'Crédits en Retard',
        message: `${overdueCredits.length} crédit(s) en retard`,
        action: 'Voir Crédits'
      });
    }

    if (!showAlerts || alerts.length === 0) return null;

    return (
      <div style={{ marginBottom: '25px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '15px' }}>
          <h3 style={{ fontSize: '18px', fontWeight: 'bold', color: isDark ? '#f7fafc' : '#2d3748', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Bell size={20} />
            Alertes Importantes
          </h3>
          <button
            onClick={() => setShowAlerts(false)}
            style={{
              background: 'transparent',
              border: 'none',
              color: isDark ? '#a0aec0' : '#64748b',
              cursor: 'pointer',
              padding: '4px'
            }}
          >
            Masquer
          </button>
        </div>
        
        {alerts.map((alert, index) => (
          <div key={index} style={styles.alertCard}>
            <alert.icon size={20} color={alert.type === 'error' ? '#ef4444' : '#f59e0b'} />
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: '600', color: isDark ? '#f87171' : '#991b1b', marginBottom: '4px' }}>
                {alert.title}
              </div>
              <div style={{ fontSize: '14px', color: isDark ? '#fca5a5' : '#dc2626' }}>
                {alert.message}
              </div>
            </div>
            <button style={{
              padding: '6px 12px',
              background: alert.type === 'error' ? '#ef4444' : '#f59e0b',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              fontSize: '12px',
              cursor: 'pointer'
            }}>
              {alert.action}
            </button>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div style={styles.container}>
      {/* En-tête avec contrôles */}
      <div style={styles.header}>
        <div>
          <h1 style={{ fontSize: '28px', fontWeight: 'bold', color: isDark ? '#f7fafc' : '#2d3748', marginBottom: '4px' }}>
            📊 Tableau de Bord - {appSettings.storeName}
          </h1>
          <p style={{ color: isDark ? '#a0aec0' : '#64748b' }}>
            Vue d'ensemble de votre activité - {dashboardMetrics.periodLabel}
          </p>
        </div>
        
        <div style={styles.headerControls}>
          {/* Sélecteur de période */}
          <div style={styles.periodSelector}>
            {['today', 'week', 'month', 'year'].map(period => {
              const labels = { today: "Aujourd'hui", week: '7 jours', month: 'Mois', year: 'Année' };
              return (
                <button
                  key={period}
                  onClick={() => setSelectedPeriod(period)}
                  style={{
                    ...styles.periodButton,
                    background: selectedPeriod === period ? '#3b82f6' : 'transparent',
                    color: selectedPeriod === period ? 'white' : (isDark ? '#cbd5e0' : '#4a5568')
                  }}
                >
                  {labels[period]}
                </button>
              );
            })}
          </div>

          {/* Bouton Mode Sombre */}
          <button
            onClick={() => setAppSettings({...appSettings, darkMode: !appSettings.darkMode})}
            style={{
              padding: '8px 12px',
              background: isDark ? '#4a5568' : '#e2e8f0',
              border: 'none',
              borderRadius: '6px',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '5px'
            }}
          >
            {isDark ? <Sun size={16} color="#fbbf24" /> : <Moon size={16} color="#4a5568" />}
            {isDark ? 'Clair' : 'Sombre'}
          </button>

          {/* Bouton Gestion des Données */}
          <button
            onClick={() => setShowDataManager(!showDataManager)}
            style={{
              padding: '8px 12px',
              background: '#3b82f6',
              color: 'white',
              border: 'none',
              borderRadius: '6px',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '5px'
            }}
          >
            <Database size={16} />
            Données
          </button>
        </div>
      </div>

      {/* Panneau de gestion des données */}
      {showDataManager && (
        <div style={{
          background: isDark ? '#2d3748' : 'white',
          padding: '20px',
          borderRadius: '8px',
          marginBottom: '20px',
          boxShadow: '0 1px 3px rgba(0,0,0,0.1)'
        }}>
          <h3 style={{ color: isDark ? '#f7fafc' : '#2d3748', marginBottom: '15px' }}>
            Gestion des Données Locales
          </h3>
          <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
            <button
              onClick={() => {
                const data = {
                  products: JSON.parse(localStorage.getItem('pos_products') || '[]'),
                  sales: JSON.parse(localStorage.getItem('pos_sales') || '[]'),
                  customers: JSON.parse(localStorage.getItem('pos_customers') || '[]'),
                  credits: JSON.parse(localStorage.getItem('pos_credits') || '[]'),
                  settings: JSON.parse(localStorage.getItem('pos_settings') || '{}')
                };
                const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `backup_${new Date().toISOString().split('T')[0]}.json`;
                a.click();
              }}
              style={{
                padding: '8px 16px',
                background: '#10b981',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                cursor: 'pointer'
              }}
            >
              📥 Exporter Sauvegarde
            </button>

            <button
              onClick={() => {
                const input = document.createElement('input');
                input.type = 'file';
                input.accept = '.json';
                input.onchange = (e) => {
                  const file = e.target.files[0];
                  const reader = new FileReader();
                  reader.onload = (event) => {
                    try {
                      const data = JSON.parse(event.target.result);
                      if (data.products) localStorage.setItem('pos_products', JSON.stringify(data.products));
                      if (data.sales) localStorage.setItem('pos_sales', JSON.stringify(data.sales));
                      if (data.customers) localStorage.setItem('pos_customers', JSON.stringify(data.customers));
                      if (data.credits) localStorage.setItem('pos_credits', JSON.stringify(data.credits));
                      if (data.settings) localStorage.setItem('pos_settings', JSON.stringify(data.settings));
                      alert('✅ Données restaurées avec succès! Rechargement...');
                      window.location.reload();
                    } catch (error) {
                      alert('❌ Erreur lors de la restauration des données');
                    }
                  };
                  reader.readAsText(file);
                };
                input.click();
              }}
              style={{
                padding: '8px 16px',
                background: '#3b82f6',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                cursor: 'pointer'
              }}
            >
              📤 Importer Sauvegarde
            </button>

            <button
              onClick={clearAllData}
              style={{
                padding: '8px 16px',
                background: '#ef4444',
                color: 'white',
                border: 'none',
                borderRadius: '6px',
                cursor: 'pointer'
              }}
            >
              🗑️ Effacer Toutes les Données
            </button>
          </div>
          <p style={{ fontSize: '12px', color: isDark ? '#a0aec0' : '#718096', marginTop: '10px' }}>
            💡 Les données sont automatiquement sauvegardées localement dans votre navigateur
          </p>
        </div>
      )}

      {/* Panneau CloudSync existant */}
      <CloudSyncPanel isDark={isDark} />

      {/* Alertes */}
      <AlertsWidget />

      {/* Métriques principales avec comparaison */}
     <div style={styles.metricsGrid}>
       <MetricCard
         title={`Chiffre d'Affaires - ${dashboardMetrics.periodLabel}`}
         value={dashboardMetrics.currentRevenue}
         change={dashboardMetrics.revenueGrowth}
         icon={DollarSign}
         color="#10b981"
         format="currency"
       />
       
       <MetricCard
         title={`Nombre de Ventes - ${dashboardMetrics.periodLabel}`}
         value={dashboardMetrics.currentTransactions}
         change={dashboardMetrics.transactionGrowth}
         icon={ShoppingCart}
         color="#3b82f6"
       />
       
       <MetricCard
         title="Produits en Stock"
         value={stats.totalProducts}
         change={0}
         icon={Package}
         color="#8b5cf6"
       />
       
       <MetricCard
         title="Clients Fidèles"
         value={stats.totalCustomers}
         change={0}
         icon={Users}
         color="#f59e0b"
       />
     </div>

     {/* Graphiques et analyses */}
     <div style={styles.chartsGrid}>
       <HourlyChart />
       <TopProductsWidget />
     </div>

     {/* Statistiques existantes réutilisées */}
     <div style={styles.metricsGrid}>
       <div style={styles.metricCard}>
         <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '15px' }}>
           <Package size={24} color="#3b82f6" />
           <h3 style={{ fontSize: '18px', fontWeight: 'bold', color: isDark ? '#f7fafc' : '#2d3748' }}>
             Inventaire
           </h3>
         </div>
         
         <div style={{ marginBottom: '10px' }}>
           <div style={{ fontSize: '24px', fontWeight: 'bold', color: isDark ? '#f7fafc' : '#2d3748' }}>
             {stats.inventoryValue.toLocaleString()} {appSettings.currency}
           </div>
           <div style={{ fontSize: '14px', color: isDark ? '#a0aec0' : '#64748b' }}>
             Valeur totale du stock
           </div>
         </div>
         
         {(stats.lowStockCount > 0 || stats.outOfStockCount > 0) && (
           <div style={{ fontSize: '12px', color: '#ef4444' }}>
             ⚠️ {stats.outOfStockCount + stats.lowStockCount} alertes stock
           </div>
         )}
       </div>

       <div style={styles.metricCard}>
         <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '15px' }}>
           <BarChart3 size={24} color="#10b981" />
           <h3 style={{ fontSize: '18px', fontWeight: 'bold', color: isDark ? '#f7fafc' : '#2d3748' }}>
             Revenus Mensuels
           </h3>
         </div>
         
         <div style={{ marginBottom: '10px' }}>
           <div style={{ fontSize: '24px', fontWeight: 'bold', color: isDark ? '#f7fafc' : '#2d3748' }}>
             {stats.monthRevenue.toLocaleString()} {appSettings.currency}
           </div>
           <div style={{ fontSize: '14px', color: isDark ? '#a0aec0' : '#64748b' }}>
             {stats.monthTransactions} ventes ce mois
           </div>
         </div>
         
         <div style={{ fontSize: '12px', color: '#10b981' }}>
           ✓ Performance mensuelle
         </div>
       </div>

       <div style={styles.metricCard}>
         <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '15px' }}>
           <Clock size={24} color="#f59e0b" />
           <h3 style={{ fontSize: '18px', fontWeight: 'bold', color: isDark ? '#f7fafc' : '#2d3748' }}>
             Crédits
           </h3>
         </div>
         
         <div style={{ marginBottom: '10px' }}>
           <div style={{ fontSize: '24px', fontWeight: 'bold', color: isDark ? '#f7fafc' : '#2d3748' }}>
             {((credits || []).filter(c => c.status === 'pending' || c.status === 'partial')
               .reduce((sum, c) => sum + c.remainingAmount, 0)).toLocaleString()} {appSettings.currency}
           </div>
           <div style={{ fontSize: '14px', color: isDark ? '#a0aec0' : '#64748b' }}>
             Crédits en cours
           </div>
         </div>
         
         {((credits || []).filter(c => {
           const dueDate = new Date(c.dueDate);
           return (c.status === 'pending' || c.status === 'partial') && dueDate < new Date();
         }).length > 0) && (
           <div style={{ fontSize: '12px', color: '#ef4444' }}>
             ⚠️ Crédits en retard détectés
           </div>
         )}
       </div>

       <div style={styles.metricCard}>
         <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '15px' }}>
           <Target size={24} color="#06b6d4" />
           <h3 style={{ fontSize: '18px', fontWeight: 'bold', color: isDark ? '#f7fafc' : '#2d3748' }}>
             Performance
           </h3>
         </div>
         
         <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', fontSize: '14px' }}>
           <div>
             <div style={{ color: isDark ? '#a0aec0' : '#64748b' }}>Taux TVA</div>
             <div style={{ fontWeight: 'bold', color: isDark ? '#f7fafc' : '#2d3748' }}>
               {appSettings.taxRate}%
             </div>
           </div>
           <div>
             <div style={{ color: isDark ? '#a0aec0' : '#64748b' }}>Points fidélité</div>
             <div style={{ fontWeight: 'bold', color: isDark ? '#f7fafc' : '#2d3748' }}>
               1pt/1000 {appSettings.currency}
             </div>
           </div>
         </div>
       </div>
     </div>

     {/* Alertes importantes réutilisées du code existant */}
     {(stats.lowStockCount > 0 || stats.outOfStockCount > 0) && (
       <div style={{ 
         marginTop: '20px', 
         padding: '15px', 
         background: isDark ? '#431018' : '#fef2f2', 
         borderRadius: '8px',
         border: `1px solid ${isDark ? '#7f1d1d' : '#fecaca'}`,
         display: 'flex',
         alignItems: 'center',
         gap: '15px'
       }}>
         <AlertTriangle size={24} color="#ef4444" />
         <div>
           <h3 style={{ color: isDark ? '#f87171' : '#991b1b', marginBottom: '5px' }}>
             Alertes Stock Critiques
           </h3>
           <p style={{ color: isDark ? '#fca5a5' : '#dc2626', fontSize: '14px' }}>
             {stats.outOfStockCount > 0 && `${stats.outOfStockCount} produit(s) en rupture de stock. `}
             {stats.lowStockCount > 0 && `${stats.lowStockCount} produit(s) en stock faible.`}
             {' '}Vérifiez l'onglet Stocks pour plus de détails.
           </p>
         </div>
       </div>
     )}

     {/* Résumé financier existant */}
     <div style={{ 
       marginTop: '20px', 
       padding: '20px', 
       background: isDark ? '#2d3748' : 'white', 
       borderRadius: '8px',
       boxShadow: '0 1px 3px rgba(0,0,0,0.1)'
     }}>
       <h3 style={{ color: isDark ? '#f7fafc' : '#2d3748', marginBottom: '15px' }}>
         📊 Résumé Financier
       </h3>
       <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '15px' }}>
         <div>
           <div style={{ fontSize: '14px', color: isDark ? '#a0aec0' : '#718096' }}>Valeur de l'inventaire</div>
           <div style={{ fontSize: '20px', fontWeight: 'bold', color: '#3b82f6' }}>
             {stats.inventoryValue.toLocaleString()} {appSettings.currency}
           </div>
         </div>
         <div>
           <div style={{ fontSize: '14px', color: isDark ? '#a0aec0' : '#718096' }}>Ventes aujourd'hui</div>
           <div style={{ fontSize: '20px', fontWeight: 'bold', color: '#10b981' }}>
             {stats.todayRevenue.toLocaleString()} {appSettings.currency}
           </div>
         </div>
         <div>
           <div style={{ fontSize: '14px', color: isDark ? '#a0aec0' : '#718096' }}>Transactions du jour</div>
           <div style={{ fontSize: '20px', fontWeight: 'bold', color: isDark ? '#f7fafc' : '#2d3748' }}>
             {stats.todayTransactions}
           </div>
         </div>
       </div>
     </div>
   </div>
 );
};

export default DashboardModule;