import BarcodeSystem from './BarcodeSystem';
import PhysicalInventory from './PhysicalInventory';
import React, { useState, useEffect } from 'react';
import { 
  Package, AlertTriangle, TrendingDown, TrendingUp, 
  Search, Plus, Minus, Edit, Save, X, Bell,
  BarChart3, Truck, Clock, Eye, RefreshCw
} from 'lucide-react';
import { useMultiStore } from '../../contexts/MultiStoreContext';

const InventoryModule = () => {
  const { globalProducts, setGlobalProducts, addStock, appSettings, salesHistory } = useMultiStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showRestockModal, setShowRestockModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [restockingProduct, setRestockingProduct] = useState(null);
  const [restockQuantity, setRestockQuantity] = useState('');
  const [activeTab, setActiveTab] = useState('overview');

  // Utiliser globalProducts
  const products = globalProducts;

  // Calculs statistiques mis à jour
  const stats = {
    totalProducts: products.length,
    totalValue: products.reduce((sum, p) => sum + (p.stock * p.costPrice), 0),
    lowStock: products.filter(p => p.stock > 0 && p.stock <= p.minStock).length,
    outOfStock: products.filter(p => p.stock === 0).length,
    overStock: products.filter(p => p.stock > p.maxStock).length,
    totalSalesValue: products.reduce((sum, p) => sum + (p.stock * p.price), 0)
  };

  // Calculer les mouvements de stock basés sur l'historique des ventes
  const stockMovements = salesHistory.flatMap(sale => 
    sale.items.map(item => ({
      date: sale.date,
      productName: item.name,
      quantity: -item.quantity,
      type: 'Vente',
      reference: sale.receiptNumber
    }))
  ).sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 10);

  const isDark = appSettings.darkMode;

  // Styles mis à jour avec thème
  const styles = {
    container: {
      padding: '20px',
      background: isDark ? '#1a202c' : '#f7fafc',
      minHeight: 'calc(100vh - 120px)'
    },
    header: {
      background: isDark ? '#2d3748' : 'white',
      padding: '20px',
      borderRadius: '8px',
      marginBottom: '20px',
      boxShadow: '0 1px 3px rgba(0,0,0,0.1)'
    },
    tabs: {
      display: 'flex',
      gap: '10px',
      marginBottom: '20px',
      borderBottom: `2px solid ${isDark ? '#4a5568' : '#e2e8f0'}`,
      background: isDark ? '#2d3748' : 'white',
      padding: '0 20px',
      borderRadius: '8px 8px 0 0'
    },
    tab: {
      padding: '15px 20px',
      background: 'transparent',
      border: 'none',
      cursor: 'pointer',
      fontSize: '14px',
      fontWeight: '600',
      color: isDark ? '#cbd5e0' : '#64748b',
      borderBottom: '3px solid transparent',
      marginBottom: '-2px',
      transition: 'all 0.2s'
    },
    activeTab: {
      color: '#3b82f6',
      borderBottomColor: '#3b82f6'
    },
    statsGrid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
      gap: '15px',
      marginBottom: '20px'
    },
    statCard: {
      background: isDark ? '#2d3748' : 'white',
      padding: '20px',
      borderRadius: '8px',
      boxShadow: '0 1px 3px rgba(0,0,0,0.1)'
    },
    table: {
      width: '100%',
      background: isDark ? '#2d3748' : 'white',
      borderRadius: '8px',
      overflow: 'hidden',
      boxShadow: '0 1px 3px rgba(0,0,0,0.1)'
    },
    th: {
      padding: '12px',
      background: isDark ? '#374151' : '#f8fafc',
      textAlign: 'left',
      fontSize: '12px',
      fontWeight: '600',
      color: isDark ? '#a0aec0' : '#64748b',
      textTransform: 'uppercase',
      borderBottom: `1px solid ${isDark ? '#4a5568' : '#e2e8f0'}`
    },
    td: {
      padding: '12px',
      borderBottom: `1px solid ${isDark ? '#374151' : '#f1f5f9'}`,
      fontSize: '14px',
      color: isDark ? '#f7fafc' : '#2d3748'
    }
  };

  // Filtrer les produits
  const filteredProducts = products.filter(product => {
    const matchSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        product.sku.toLowerCase().includes(searchTerm.toLowerCase());
    const matchCategory = selectedCategory === 'all' || product.category === selectedCategory;
    return matchSearch && matchCategory;
  });

  // Obtenir le statut du stock
  const getStockStatus = (product) => {
    if (product.stock === 0) return { label: 'Rupture', color: '#ef4444', bg: '#fef2f2' };
    if (product.stock <= product.minStock) return { label: 'Faible', color: '#f59e0b', bg: '#fffbeb' };
    if (product.stock > product.maxStock) return { label: 'Excès', color: '#8b5cf6', bg: '#f3f0ff' };
    return { label: 'Normal', color: '#10b981', bg: '#f0fdf4' };
  };

  // Fonction pour réapprovisionner
  const handleRestock = () => {
    if (restockingProduct && restockQuantity > 0) {
      addStock(restockingProduct.id, parseInt(restockQuantity), 'Réapprovisionnement manuel');
      alert(`✅ Stock ajouté: ${restockQuantity} unités de ${restockingProduct.name}`);
      setShowRestockModal(false);
      setRestockQuantity('');
      setRestockingProduct(null);
    }
  };

  // Fonction pour ajouter un nouveau produit
  const handleAddProduct = (formData) => {
    const newProduct = {
      ...formData,
      id: Date.now(),
      stock: parseInt(formData.stock),
      minStock: parseInt(formData.minStock),
      maxStock: parseInt(formData.maxStock),
      price: parseFloat(formData.price),
      costPrice: parseFloat(formData.costPrice)
    };
    setGlobalProducts([...products, newProduct]);
    setShowAddModal(false);
    alert('✅ Produit ajouté avec succès!');
  };

  // Fonction pour modifier un produit
  const handleEditProduct = (formData) => {
    setGlobalProducts(products.map(p => 
      p.id === editingProduct.id 
        ? { ...formData, id: p.id }
        : p
    ));
    setShowEditModal(false);
    alert('✅ Produit modifié avec succès!');
  };

  // Vue d'ensemble
  const OverviewTab = () => (
    <div>
      {/* Statistiques */}
      <div style={styles.statsGrid}>
        <div style={styles.statCard}>
          <Package size={24} color="#3b82f6" />
          <div style={{ fontSize: '28px', fontWeight: 'bold', marginTop: '10px', color: isDark ? '#f7fafc' : '#2d3748' }}>
            {stats.totalProducts}
          </div>
          <div style={{ fontSize: '14px', color: isDark ? '#a0aec0' : '#64748b' }}>Total Produits</div>
        </div>
        <div style={styles.statCard}>
          <BarChart3 size={24} color="#10b981" />
          <div style={{ fontSize: '28px', fontWeight: 'bold', marginTop: '10px', color: isDark ? '#f7fafc' : '#2d3748' }}>
            {stats.totalValue.toLocaleString()} {appSettings.currency}
          </div>
          <div style={{ fontSize: '14px', color: isDark ? '#a0aec0' : '#64748b' }}>Valeur d'Achat</div>
        </div>
        <div style={styles.statCard}>
          <TrendingUp size={24} color="#06b6d4" />
          <div style={{ fontSize: '28px', fontWeight: 'bold', marginTop: '10px', color: isDark ? '#f7fafc' : '#2d3748' }}>
            {stats.totalSalesValue.toLocaleString()} {appSettings.currency}
          </div>
          <div style={{ fontSize: '14px', color: isDark ? '#a0aec0' : '#64748b' }}>Valeur de Vente</div>
        </div>
        <div style={styles.statCard}>
          <AlertTriangle size={24} color="#f59e0b" />
          <div style={{ fontSize: '28px', fontWeight: 'bold', marginTop: '10px', color: isDark ? '#f7fafc' : '#2d3748' }}>
            {stats.lowStock + stats.outOfStock}
          </div>
          <div style={{ fontSize: '14px', color: isDark ? '#a0aec0' : '#64748b' }}>Alertes Stock</div>
        </div>
      </div>

      {/* Alertes */}
      {products.filter(p => p.stock <= p.minStock).length > 0 && (
        <div style={{ marginBottom: '20px' }}>
          <h3 style={{ fontSize: '18px', fontWeight: 'bold', marginBottom: '15px', display: 'flex', alignItems: 'center', gap: '10px', color: isDark ? '#f7fafc' : '#2d3748' }}>
            <Bell size={20} color="#ef4444" />
            Produits à Réapprovisionner
          </h3>
          {products.filter(p => p.stock <= p.minStock).map(product => (
            <div key={product.id} style={{
              background: '#fef2f2',
              border: '1px solid #fecaca',
              borderRadius: '8px',
              padding: '15px',
              marginBottom: '15px',
              display: 'flex',
              alignItems: 'center',
              gap: '15px'
            }}>
              <AlertTriangle size={20} color="#ef4444" />
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: '600', marginBottom: '5px', color: '#991b1b' }}>{product.name}</div>
                <div style={{ fontSize: '14px', color: '#dc2626' }}>
                  Stock actuel: {product.stock} | Minimum requis: {product.minStock}
                </div>
              </div>
              <button
                style={{
                  background: '#ef4444',
                  color: 'white',
                  border: 'none',
                  padding: '8px 16px',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  fontWeight: '600'
                }}
                onClick={() => {
                  setRestockingProduct(product);
                  setRestockQuantity(product.maxStock - product.stock);
                  setShowRestockModal(true);
                }}
              >
                Réapprovisionner
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Mouvements récents */}
      <div style={{ background: isDark ? '#2d3748' : 'white', padding: '20px', borderRadius: '8px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
        <h3 style={{ fontSize: '18px', fontWeight: 'bold', marginBottom: '15px', color: isDark ? '#f7fafc' : '#2d3748' }}>
          Mouvements Récents
        </h3>
        {stockMovements.length > 0 ? (
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%' }}>
              <thead>
                <tr>
                  <th style={{ ...styles.th, textAlign: 'left' }}>Date</th>
                  <th style={{ ...styles.th, textAlign: 'left' }}>Produit</th>
                  <th style={{ ...styles.th, textAlign: 'left' }}>Quantité</th>
                  <th style={{ ...styles.th, textAlign: 'left' }}>Type</th>
                  <th style={{ ...styles.th, textAlign: 'left' }}>Référence</th>
                </tr>
              </thead>
              <tbody>
                {stockMovements.map((movement, index) => (
                  <tr key={index}>
                    <td style={styles.td}>
                      {new Date(movement.date).toLocaleDateString('fr-FR')}
                    </td>
                    <td style={styles.td}>{movement.productName}</td>
                    <td style={styles.td}>
                      <span style={{ color: movement.quantity < 0 ? '#ef4444' : '#10b981', fontWeight: 'bold' }}>
                        {movement.quantity > 0 ? '+' : ''}{movement.quantity}
                      </span>
                    </td>
                    <td style={styles.td}>{movement.type}</td>
                    <td style={styles.td}>
                      <span style={{ fontFamily: 'monospace', fontSize: '12px' }}>{movement.reference}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p style={{ color: isDark ? '#a0aec0' : '#718096' }}>Aucun mouvement récent</p>
        )}
      </div>
    </div>
  );

  // Liste des produits
  const ProductsTab = () => (
    <div>
      {/* Barre de recherche et actions */}
      <div style={{ display: 'flex', gap: '10px', marginBottom: '20px' }}>
        <input
          type="text"
          placeholder="Rechercher par nom ou SKU..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          style={{
            flex: 1,
            padding: '10px 15px',
            border: `1px solid ${isDark ? '#4a5568' : '#e2e8f0'}`,
            borderRadius: '8px',
            fontSize: '14px',
            background: isDark ? '#374151' : 'white',
            color: isDark ? '#f7fafc' : '#2d3748'
          }}
        />
        <select
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
          style={{
            padding: '10px 15px',
            border: `1px solid ${isDark ? '#4a5568' : '#e2e8f0'}`,
            borderRadius: '8px',
            fontSize: '14px',
            background: isDark ? '#374151' : 'white',
            color: isDark ? '#f7fafc' : '#2d3748',
            cursor: 'pointer'
          }}
        >
          <option value="all">Toutes catégories</option>
          <option value="Boissons">Boissons</option>
          <option value="Épicerie">Épicerie</option>
          <option value="Boulangerie">Boulangerie</option>
          <option value="Produits laitiers">Produits laitiers</option>
          <option value="Hygiène">Hygiène</option>
          <option value="Légumes">Légumes</option>
          <option value="Viande">Viande</option>
          <option value="Produits frais">Produits frais</option>
        </select>
        <button 
          style={{
            padding: '10px 20px',
            background: '#3b82f6',
            color: 'white',
            border: 'none',
            borderRadius: '8px',
            fontSize: '14px',
            fontWeight: '600',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: '8px'
          }}
          onClick={() => setShowAddModal(true)}
        >
          <Plus size={18} />
          Nouveau Produit
        </button>
      </div>

      {/* Tableau des produits */}
      <table style={styles.table}>
        <thead>
          <tr>
            <th style={styles.th}>SKU</th>
            <th style={styles.th}>Nom</th>
            <th style={styles.th}>Catégorie</th>
            <th style={styles.th}>Stock</th>
            <th style={styles.th}>Min/Max</th>
            <th style={styles.th}>Prix Achat</th>
            <th style={styles.th}>Prix Vente</th>
            <th style={styles.th}>Marge</th>
            <th style={styles.th}>Statut</th>
            <th style={styles.th}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredProducts.map(product => {
            const status = getStockStatus(product);
            const margin = ((product.price - product.costPrice) / product.price * 100).toFixed(1);
            
            return (
              <tr key={product.id}>
                <td style={styles.td}>{product.sku}</td>
                <td style={styles.td}>
                  <div style={{ fontWeight: '600' }}>{product.name}</div>
                </td>
                <td style={styles.td}>{product.category}</td>
                <td style={styles.td}>
                  <div style={{ fontWeight: '600', color: status.color }}>{product.stock}</div>
                </td>
                <td style={styles.td}>{product.minStock}/{product.maxStock}</td>
                <td style={styles.td}>{product.costPrice} {appSettings.currency}</td>
                <td style={styles.td}>{product.price} {appSettings.currency}</td>
                <td style={styles.td}>
                  <span style={{ color: margin > 30 ? '#10b981' : margin > 15 ? '#f59e0b' : '#ef4444', fontWeight: '600' }}>
                    {margin}%
                  </span>
                </td>
                <td style={styles.td}>
                  <span style={{ 
                    padding: '4px 12px', 
                    borderRadius: '12px', 
                    fontSize: '12px', 
                    fontWeight: '600',
                    background: status.bg, 
                    color: status.color 
                  }}>
                    {status.label}
                  </span>
                </td>
                <td style={styles.td}>
                  <div style={{ display: 'flex', gap: '5px' }}>
                    <button
                      onClick={() => {
                        setRestockingProduct(product);
                        setRestockQuantity('');
                        setShowRestockModal(true);
                      }}
                      style={{ 
                        padding: '5px 10px', 
                        background: '#10b981', 
                        color: 'white',
                        border: 'none',
                        borderRadius: '4px',
                        cursor: 'pointer',
                        fontSize: '12px'
                      }}
                    >
                      <RefreshCw size={12} style={{ display: 'inline' }} />
                    </button>
                    <button
                      onClick={() => {
                        setEditingProduct(product);
                        setShowEditModal(true);
                      }}
                      style={{ 
                        padding: '5px 10px', 
                        background: '#3b82f6', 
                        color: 'white',
                        border: 'none',
                        borderRadius: '4px',
                        cursor: 'pointer',
                        fontSize: '12px'
                      }}
                    >
                      <Edit size={12} style={{ display: 'inline' }} />
                    </button>
                  </div>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );

   // Modal d'ajout de produit
  const AddProductModal = () => {
    const [formData, setFormData] = useState({
      name: '',
      sku: '',
      category: 'Épicerie',
      stock: 0,
      minStock: 10,
      maxStock: 100,
      price: 0,
      costPrice: 0,
      supplier: 'Distributions ABC',
      image: '📦'
    });

    const handleSubmit = (e) => {
      e.preventDefault();
      const newProduct = {
        ...formData,
        id: Date.now(),
        stock: parseInt(formData.stock),
        minStock: parseInt(formData.minStock),
        maxStock: parseInt(formData.maxStock),
        price: parseFloat(formData.price),
        costPrice: parseFloat(formData.costPrice)
      };
      setGlobalProducts([...globalProducts, newProduct]);
      setShowAddModal(false);
      alert('✅ Produit ajouté avec succès!');
    };

    return (
      <div style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: 'rgba(0,0,0,0.5)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 1000
      }}>
        <div style={{
          background: isDark ? '#2d3748' : 'white',
          padding: '30px',
          borderRadius: '12px',
          width: '90%',
          maxWidth: '500px',
          maxHeight: '90vh',
          overflowY: 'auto'
        }}>
          <h3 style={{ marginBottom: '20px', color: isDark ? '#f7fafc' : '#2d3748' }}>
            Ajouter un nouveau produit
          </h3>
          
          <form onSubmit={handleSubmit}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px' }}>
              <div>
                <label style={{ display: 'block', marginBottom: '5px', fontSize: '14px', color: isDark ? '#a0aec0' : '#718096' }}>
                  Nom du produit *
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  style={{
                    width: '100%',
                    padding: '8px',
                    border: `1px solid ${isDark ? '#4a5568' : '#e2e8f0'}`,
                    borderRadius: '6px',
                    background: isDark ? '#374151' : 'white',
                    color: isDark ? '#f7fafc' : '#2d3748'
                  }}
                />
              </div>
              
              <div>
                <label style={{ display: 'block', marginBottom: '5px', fontSize: '14px', color: isDark ? '#a0aec0' : '#718096' }}>
                  SKU *
                </label>
                <input
                  type="text"
                  required
                  value={formData.sku}
                  onChange={(e) => setFormData({...formData, sku: e.target.value})}
                  style={{
                    width: '100%',
                    padding: '8px',
                    border: `1px solid ${isDark ? '#4a5568' : '#e2e8f0'}`,
                    borderRadius: '6px',
                    background: isDark ? '#374151' : 'white',
                    color: isDark ? '#f7fafc' : '#2d3748'
                  }}
                />
              </div>
              
              <div>
                <label style={{ display: 'block', marginBottom: '5px', fontSize: '14px', color: isDark ? '#a0aec0' : '#718096' }}>
                  Catégorie
                </label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({...formData, category: e.target.value})}
                  style={{
                    width: '100%',
                    padding: '8px',
                    border: `1px solid ${isDark ? '#4a5568' : '#e2e8f0'}`,
                    borderRadius: '6px',
                    background: isDark ? '#374151' : 'white',
                    color: isDark ? '#f7fafc' : '#2d3748'
                  }}
                >
                  <option value="Boissons">Boissons</option>
                  <option value="Épicerie">Épicerie</option>
                  <option value="Boulangerie">Boulangerie</option>
                  <option value="Produits laitiers">Produits laitiers</option>
                  <option value="Hygiène">Hygiène</option>
                  <option value="Légumes">Légumes</option>
                  <option value="Viande">Viande</option>
                  <option value="Produits frais">Produits frais</option>
                </select>
              </div>
              
              <div>
                <label style={{ display: 'block', marginBottom: '5px', fontSize: '14px', color: isDark ? '#a0aec0' : '#718096' }}>
                  Stock initial
                </label>
                <input
                  type="number"
                  value={formData.stock}
                  onChange={(e) => setFormData({...formData, stock: e.target.value})}
                  style={{
                    width: '100%',
                    padding: '8px',
                    border: `1px solid ${isDark ? '#4a5568' : '#e2e8f0'}`,
                    borderRadius: '6px',
                    background: isDark ? '#374151' : 'white',
                    color: isDark ? '#f7fafc' : '#2d3748'
                  }}
                />
              </div>
              
              <div>
                <label style={{ display: 'block', marginBottom: '5px', fontSize: '14px', color: isDark ? '#a0aec0' : '#718096' }}>
                  Prix d'achat *
                </label>
                <input
                  type="number"
                  required
                  value={formData.costPrice}
                  onChange={(e) => setFormData({...formData, costPrice: e.target.value})}
                  style={{
                    width: '100%',
                    padding: '8px',
                    border: `1px solid ${isDark ? '#4a5568' : '#e2e8f0'}`,
                    borderRadius: '6px',
                    background: isDark ? '#374151' : 'white',
                    color: isDark ? '#f7fafc' : '#2d3748'
                  }}
                />
              </div>
              
              <div>
                <label style={{ display: 'block', marginBottom: '5px', fontSize: '14px', color: isDark ? '#a0aec0' : '#718096' }}>
                  Prix de vente *
                </label>
                <input
                  type="number"
                  required
                  value={formData.price}
                  onChange={(e) => setFormData({...formData, price: e.target.value})}
                  style={{
                    width: '100%',
                    padding: '8px',
                    border: `1px solid ${isDark ? '#4a5568' : '#e2e8f0'}`,
                    borderRadius: '6px',
                    background: isDark ? '#374151' : 'white',
                    color: isDark ? '#f7fafc' : '#2d3748'
                  }}
                />
              </div>
            </div>
            
            <div style={{ display: 'flex', gap: '10px', marginTop: '20px' }}>
              <button
                type="submit"
                style={{
                  flex: 1,
                  padding: '10px',
                  background: '#10b981',
                  color: 'white',
                  border: 'none',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  fontWeight: '600'
                }}
              >
                Ajouter
              </button>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                style={{
                  flex: 1,
                  padding: '10px',
                  background: '#64748b',
                  color: 'white',
                  border: 'none',
                  borderRadius: '6px',
                  cursor: 'pointer'
                }}
              >
                Annuler
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  };

  // Modal d'édition de produit
  const EditProductModal = () => {
    const [formData, setFormData] = useState(editingProduct || {});

    const handleSubmit = (e) => {
      e.preventDefault();
      setGlobalProducts(globalProducts.map(p => 
        p.id === editingProduct.id ? {
          ...formData,
          stock: parseInt(formData.stock),
          minStock: parseInt(formData.minStock),
          maxStock: parseInt(formData.maxStock),
          price: parseFloat(formData.price),
          costPrice: parseFloat(formData.costPrice)
        } : p
      ));
      setShowEditModal(false);
      alert('✅ Produit modifié avec succès!');
    };

    return (
      <div style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: 'rgba(0,0,0,0.5)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 1000
      }}>
        <div style={{
          background: isDark ? '#2d3748' : 'white',
          padding: '30px',
          borderRadius: '12px',
          width: '90%',
          maxWidth: '500px',
          maxHeight: '90vh',
          overflowY: 'auto'
        }}>
          <h3 style={{ marginBottom: '20px', color: isDark ? '#f7fafc' : '#2d3748' }}>
            Modifier le produit
          </h3>
          
          <form onSubmit={handleSubmit}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px' }}>
              <div>
                <label style={{ display: 'block', marginBottom: '5px', fontSize: '14px', color: isDark ? '#a0aec0' : '#718096' }}>
                  Nom du produit
                </label>
                <input
                  type="text"
                  value={formData.name || ''}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  style={{
                    width: '100%',
                    padding: '8px',
                    border: `1px solid ${isDark ? '#4a5568' : '#e2e8f0'}`,
                    borderRadius: '6px',
                    background: isDark ? '#374151' : 'white',
                    color: isDark ? '#f7fafc' : '#2d3748'
                  }}
                />
              </div>
              
              <div>
                <label style={{ display: 'block', marginBottom: '5px', fontSize: '14px', color: isDark ? '#a0aec0' : '#718096' }}>
                  SKU
                </label>
                <input
                  type="text"
                  value={formData.sku || ''}
                  onChange={(e) => setFormData({...formData, sku: e.target.value})}
                  style={{
                    width: '100%',
                    padding: '8px',
                    border: `1px solid ${isDark ? '#4a5568' : '#e2e8f0'}`,
                    borderRadius: '6px',
                    background: isDark ? '#374151' : 'white',
                    color: isDark ? '#f7fafc' : '#2d3748'
                  }}
                />
              </div>
              
              <div>
                <label style={{ display: 'block', marginBottom: '5px', fontSize: '14px', color: isDark ? '#a0aec0' : '#718096' }}>
                  Stock actuel
                </label>
                <input
                  type="number"
                  value={formData.stock || 0}
                  onChange={(e) => setFormData({...formData, stock: e.target.value})}
                  style={{
                    width: '100%',
                    padding: '8px',
                    border: `1px solid ${isDark ? '#4a5568' : '#e2e8f0'}`,
                    borderRadius: '6px',
                    background: isDark ? '#374151' : 'white',
                    color: isDark ? '#f7fafc' : '#2d3748'
                  }}
                />
              </div>
              
              <div>
                <label style={{ display: 'block', marginBottom: '5px', fontSize: '14px', color: isDark ? '#a0aec0' : '#718096' }}>
                  Prix de vente
                </label>
                <input
                  type="number"
                  value={formData.price || 0}
                  onChange={(e) => setFormData({...formData, price: e.target.value})}
                  style={{
                    width: '100%',
                    padding: '8px',
                    border: `1px solid ${isDark ? '#4a5568' : '#e2e8f0'}`,
                    borderRadius: '6px',
                    background: isDark ? '#374151' : 'white',
                    color: isDark ? '#f7fafc' : '#2d3748'
                  }}
                />
              </div>
            </div>
            
            <div style={{ display: 'flex', gap: '10px', marginTop: '20px' }}>
              <button
                type="submit"
                style={{
                  flex: 1,
                  padding: '10px',
                  background: '#3b82f6',
                  color: 'white',
                  border: 'none',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  fontWeight: '600'
                }}
              >
                Sauvegarder
              </button>
              <button
                type="button"
                onClick={() => setShowEditModal(false)}
                style={{
                  flex: 1,
                  padding: '10px',
                  background: '#64748b',
                  color: 'white',
                  border: 'none',
                  borderRadius: '6px',
                  cursor: 'pointer'
                }}
              >
                Annuler
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  };

  // Modal de réapprovisionnement
  const RestockModal = () => (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: 'rgba(0,0,0,0.5)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 1000
    }}>
      <div style={{
        background: isDark ? '#2d3748' : 'white',
        padding: '30px',
        borderRadius: '12px',
        width: '90%',
        maxWidth: '400px'
      }}>
        <h3 style={{ marginBottom: '20px', color: isDark ? '#f7fafc' : '#2d3748' }}>
          Réapprovisionner: {restockingProduct?.name}
        </h3>
        
        <div style={{ marginBottom: '15px' }}>
          <div style={{ fontSize: '14px', color: isDark ? '#a0aec0' : '#718096', marginBottom: '10px' }}>
            Stock actuel: {restockingProduct?.stock} | 
            Min: {restockingProduct?.minStock} | 
            Max: {restockingProduct?.maxStock}
          </div>
        </div>

        <div style={{ marginBottom: '20px' }}>
          <label style={{ display: 'block', marginBottom: '5px', color: isDark ? '#a0aec0' : '#718096' }}>
            Quantité à ajouter
          </label>
          <input
            type="number"
            value={restockQuantity}
            onChange={(e) => setRestockQuantity(e.target.value)}
            style={{
              width: '100%',
              padding: '10px',
              border: `1px solid ${isDark ? '#4a5568' : '#e2e8f0'}`,
              borderRadius: '6px',
              fontSize: '16px',
              background: isDark ? '#374151' : 'white',
              color: isDark ? '#f7fafc' : '#2d3748'
            }}
          />
        </div>

        {restockQuantity && (
          <div style={{ 
            marginBottom: '20px', 
            padding: '10px', 
            background: '#f0fdf4', 
            borderRadius: '6px',
            border: '1px solid #bbf7d0'
          }}>
            <div style={{ color: '#166534', fontSize: '14px' }}>
              Nouveau stock: {restockingProduct?.stock + parseInt(restockQuantity || 0)}
            </div>
          </div>
        )}

        <div style={{ display: 'flex', gap: '10px' }}>
          <button
            onClick={handleRestock}
            style={{
              flex: 1,
              padding: '10px',
              background: '#10b981',
              color: 'white',
              border: 'none',
              borderRadius: '6px',
              cursor: 'pointer',
              fontWeight: '600'
            }}
          >
            Confirmer
          </button>
          <button
            onClick={() => {
              setShowRestockModal(false);
              setRestockQuantity('');
              setRestockingProduct(null);
            }}
            style={{
              flex: 1,
              padding: '10px',
              background: '#64748b',
              color: 'white',
              border: 'none',
              borderRadius: '6px',
              cursor: 'pointer'
            }}
          >
            Annuler
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div style={styles.container}>
      {/* En-tête */}
      <div style={styles.header}>
        <h1 style={{ fontSize: '24px', fontWeight: 'bold', marginBottom: '10px', color: isDark ? '#f7fafc' : '#2d3748' }}>
          Gestion des Stocks
        </h1>
        <p style={{ color: isDark ? '#a0aec0' : '#64748b' }}>
          Gérez votre inventaire, suivez les niveaux de stock et recevez des alertes
        </p>
      </div>

      {/* Onglets */}
      <div style={styles.tabs}>
        <button
          style={{ ...styles.tab, ...(activeTab === 'overview' ? styles.activeTab : {}) }}
          onClick={() => setActiveTab('overview')}
        >
          Vue d'ensemble
        </button>
        <button
          style={{ ...styles.tab, ...(activeTab === 'products' ? styles.activeTab : {}) }}
          onClick={() => setActiveTab('products')}
        >
          Produits
        </button>
        <button
          style={{ ...styles.tab, ...(activeTab === 'barcodes' ? styles.activeTab : {}) }}
          onClick={() => setActiveTab('barcodes')}
        >
          Codes-barres
        </button>
        <button
          style={{ ...styles.tab, ...(activeTab === 'inventory' ? styles.activeTab : {}) }}
          onClick={() => setActiveTab('inventory')}
        >
          Inventaire
        </button>
      </div>

      {/* Contenu des onglets */}
      <div>
        {activeTab === 'overview' && <OverviewTab />}
        {activeTab === 'products' && <ProductsTab />}
        {activeTab === 'barcodes' && <BarcodeSystem />}
        {activeTab === 'inventory' && <PhysicalInventory />}
      </div>

      {/* Modals */}
      {showRestockModal && <RestockModal />}
      {/* Modals */}
      {showAddModal && <AddProductModal />}
      {showEditModal && <EditProductModal />}
      {showRestockModal && <RestockModal />}
    </div>
  );
};

export default InventoryModule;