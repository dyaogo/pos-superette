import React, { createContext, useContext, useState, useEffect } from 'react';

const AppContext = createContext();

export const AppProvider = ({ children }) => {

  const [credits, setCredits] = useState([]);

  // État global des produits
  const [globalProducts, setGlobalProducts] = useState([
    { 
      id: 1, 
      name: 'Coca Cola 330ml', 
      price: 500, 
      stock: 45, 
      minStock: 20,
      maxStock: 100,
      costPrice: 350,
      image: '🥤', 
      category: 'Boissons',
      sku: 'BEV001',
      supplier: 'Distributions ABC'
    },
    { 
      id: 2, 
      name: 'Pain de mie', 
      price: 800, 
      stock: 12, 
      minStock: 30,
      maxStock: 150,
      costPrice: 600,
      image: '🍞', 
      category: 'Boulangerie',
      sku: 'BAK001',
      supplier: 'Boulangerie Centrale'
    },
    { 
      id: 3, 
      name: 'Lait 1L', 
      price: 650, 
      stock: 30, 
      minStock: 25,
      maxStock: 120,
      costPrice: 480,
      image: '🥛', 
      category: 'Produits laitiers',
      sku: 'DAI001',
      supplier: 'Laiterie Nationale'
    },
    { 
      id: 4, 
      name: 'Riz 5kg', 
      price: 3500, 
      stock: 25, 
      minStock: 10,
      maxStock: 80,
      costPrice: 2800,
      image: '🍚', 
      category: 'Épicerie',
      sku: 'GRO001',
      supplier: 'Distributions ABC'
    },
    { 
      id: 5, 
      name: 'Huile 1L', 
      price: 1200, 
      stock: 18, 
      minStock: 15,
      maxStock: 60,
      costPrice: 950,
      image: '🍶', 
      category: 'Épicerie',
      sku: 'GRO002',
      supplier: 'Distributions ABC'
    },
    { 
      id: 6, 
      name: 'Savon', 
      price: 350, 
      stock: 50, 
      minStock: 20,
      maxStock: 200,
      costPrice: 250,
      image: '🧼', 
      category: 'Hygiène',
      sku: 'HYG001',
      supplier: 'Distributions ABC'
    },
    { 
      id: 7, 
      name: 'Tomates (kg)', 
      price: 400, 
      stock: 20, 
      minStock: 10,
      maxStock: 50,
      costPrice: 250,
      image: '🍅', 
      category: 'Légumes',
      sku: 'LEG001',
      supplier: 'Marché Local'
    },
    { 
      id: 8, 
      name: 'Oignons (kg)', 
      price: 300, 
      stock: 15, 
      minStock: 10,
      maxStock: 40,
      costPrice: 180,
      image: '🧅', 
      category: 'Légumes',
      sku: 'LEG002',
      supplier: 'Marché Local'
    },
    { 
      id: 9, 
      name: 'Poulet (kg)', 
      price: 2500, 
      stock: 10, 
      minStock: 5,
      maxStock: 30,
      costPrice: 1800,
      image: '🍗', 
      category: 'Viande',
      sku: 'MEA001',
      supplier: 'Ferme Locale'
    },
    { 
      id: 10, 
      name: 'Œufs (plateau)', 
      price: 1800, 
      stock: 8, 
      minStock: 10,
      maxStock: 40,
      costPrice: 1400,
      image: '🥚', 
      category: 'Produits frais',
      sku: 'FRE001',
      supplier: 'Ferme Locale'
    }
  ]);

  // État global des ventes
  const [salesHistory, setSalesHistory] = useState([]);
  
  // État global des clients
  const [customers, setCustomers] = useState([
    { id: 1, name: 'Client Comptant', phone: '', email: '', totalPurchases: 0, points: 0 }
  ]);

  // Paramètres de l'application
  const [appSettings, setAppSettings] = useState({
    storeName: 'Alimentation Wend-Kuuni',
    currency: 'FCFA',
    taxRate: 18,
    pointsPerPurchase: 1, // 1 point pour 1000 FCFA
    darkMode: false
  });

  // Dans AppContext.jsx, ajoutez cette fonction
  const addCredit = (customerId, amount, description) => {
    const credit = {
      id: Date.now(),
      customerId,
      amount,
      originalAmount: amount,
      description: description || 'Vente à crédit',
      createdAt: new Date().toISOString(),
      dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      status: 'pending',
      payments: [],
      remainingAmount: amount
    };
    
    setCredits(prev => [...prev, credit]); // Utilisez setCredits au lieu de localStorage direct
    return credit;
  };

  // ==================== SAUVEGARDE LOCALE ==================== 
  
  // Charger les données du localStorage au démarrage
  useEffect(() => {
    const loadData = () => {
      try {
        const savedProducts = localStorage.getItem('pos_products');
        const savedSales = localStorage.getItem('pos_sales');
        const savedCustomers = localStorage.getItem('pos_customers');
        const savedSettings = localStorage.getItem('pos_settings');

        if (savedProducts) setGlobalProducts(JSON.parse(savedProducts));
        if (savedSales) setSalesHistory(JSON.parse(savedSales));
        if (savedCustomers) setCustomers(JSON.parse(savedCustomers));
        if (savedSettings) setAppSettings(JSON.parse(savedSettings));
        
        console.log('✅ Données chargées depuis le stockage local');
      } catch (error) {
        console.error('Erreur lors du chargement des données:', error);
      }
    };
    const savedCredits = localStorage.getItem('pos_credits');
    if (savedCredits) setCredits(JSON.parse(savedCredits));

    loadData();
  }, []);

  // Sauvegarder automatiquement les changements
  useEffect(() => {
    localStorage.setItem('pos_products', JSON.stringify(globalProducts));
    
  }, [globalProducts]);

  useEffect(() => {
    localStorage.setItem('pos_sales', JSON.stringify(salesHistory));
  }, [salesHistory]);

  useEffect(() => {
    localStorage.setItem('pos_customers', JSON.stringify(customers));
  }, [customers]);

  useEffect(() => {
    localStorage.setItem('pos_settings', JSON.stringify(appSettings));
  }, [appSettings]);

  useEffect(() => {
  localStorage.setItem('pos_credits', JSON.stringify(credits));
}, [credits]);

  // ==================== FONCTIONS MÉTIER ====================

  // Traiter une vente et déduire du stock
  const processSale = (cart, paymentMethod, amountReceived, customerId = 1) => {
    const sale = {
      id: Date.now(),
      date: new Date().toISOString(),
      items: cart,
      total: cart.reduce((sum, item) => sum + (item.price * item.quantity), 0),
      paymentMethod,
      amountReceived,
      change: paymentMethod === 'cash' ? amountReceived - cart.reduce((sum, item) => sum + (item.price * item.quantity), 0) : 0,
      customerId,
      receiptNumber: `REC${Date.now().toString().slice(-8)}`
    };

    // Déduire du stock
    const updatedProducts = globalProducts.map(product => {
      const cartItem = cart.find(item => item.id === product.id);
      if (cartItem) {
        return {
          ...product,
          stock: Math.max(0, product.stock - cartItem.quantity)
        };
      }
      return product;
    });

    setGlobalProducts(updatedProducts);
    setSalesHistory([sale, ...salesHistory]);

    // Mettre à jour les points du client
    if (customerId !== 1) {
      const pointsEarned = Math.floor(sale.total / 1000);
      setCustomers(customers.map(c => 
        c.id === customerId 
          ? { ...c, totalPurchases: c.totalPurchases + sale.total, points: c.points + pointsEarned }
          : c
      ));
    }

    return sale;
  };

  // Ajouter du stock
  const addStock = (productId, quantity, reason = 'Réapprovisionnement') => {
    setGlobalProducts(globalProducts.map(product =>
      product.id === productId
        ? { ...product, stock: product.stock + quantity }
        : product
    ));
    
    console.log(`✅ Stock ajouté: ${quantity} unités pour le produit ${productId}`);
  };

  // Calculer les statistiques
  const getStats = () => {
    const today = new Date().toDateString();
    const todaySales = salesHistory.filter(sale => 
      new Date(sale.date).toDateString() === today
    );
    
    const thisMonth = new Date().getMonth();
    const monthSales = salesHistory.filter(sale => 
      new Date(sale.date).getMonth() === thisMonth
    );

    return {
      todayRevenue: todaySales.reduce((sum, sale) => sum + sale.total, 0),
      todayTransactions: todaySales.length,
      monthRevenue: monthSales.reduce((sum, sale) => sum + sale.total, 0),
      monthTransactions: monthSales.length,
      totalProducts: globalProducts.length,
      lowStockCount: globalProducts.filter(p => p.stock <= p.minStock).length,
      outOfStockCount: globalProducts.filter(p => p.stock === 0).length,
      totalCustomers: customers.length - 1, // -1 pour exclure "Client Comptant"
      inventoryValue: globalProducts.reduce((sum, p) => sum + (p.stock * p.costPrice), 0)
    };
  };

  // Effacer toutes les données (avec confirmation)
  const clearAllData = () => {
    if (window.confirm('⚠️ ATTENTION: Ceci effacera TOUTES les données. Êtes-vous sûr?')) {
      localStorage.clear();
      window.location.reload();
    }
  };

  const value = {
    // États
    globalProducts,
    setGlobalProducts,
    salesHistory,
    setSalesHistory,
    customers,
    setCustomers,
    appSettings,
    setAppSettings,
    credits,
    setCredits,
    
    // Fonctions
    processSale,
    addStock,
    getStats,
    clearAllData,
    addCredit,

    
  };

  return (
    <AppContext.Provider value={value}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return {
    ...context,
    globalProducts: context.globalProducts || [],
    customers: context.customers || [{ id: 1, name: 'Client Comptant', phone: '', email: '', totalPurchases: 0, points: 0 }],
    appSettings: context.appSettings || {
      storeName: 'Alimentation Wend-Kuuni',
      currency: 'FCFA',
      taxRate: 18,
      pointsPerPurchase: 1,
      darkMode: false
    }
  };
};